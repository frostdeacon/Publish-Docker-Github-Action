self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b13496aa5f799185f5bb5ea2a952e496",
    "url": "/index.html"
  },
  {
    "revision": "40e39f4d953f32bb99ff",
    "url": "/static/css/main.c3e03621.chunk.css"
  },
  {
    "revision": "411d759a812de89c7717",
    "url": "/static/js/2.30087afa.chunk.js"
  },
  {
    "revision": "40e39f4d953f32bb99ff",
    "url": "/static/js/main.352af05c.chunk.js"
  },
  {
    "revision": "e1d7ce45dff118effe63",
    "url": "/static/js/runtime-main.6fb32f60.js"
  },
  {
    "revision": "2d36b1a925432bae7f3c53a340868c6e",
    "url": "/static/media/Lato-Regular.2d36b1a9.ttf"
  },
  {
    "revision": "ade91f473255991f410f61857696434b",
    "url": "/static/media/Montserrat-Bold.ade91f47.ttf"
  },
  {
    "revision": "c87313aa86b7caa31a9a0accaa584970",
    "url": "/static/media/Rubik-Medium.c87313aa.ttf"
  },
  {
    "revision": "cb2b88a47b2a482181251d869b2e174b",
    "url": "/static/media/carret-down.cb2b88a4.svg"
  },
  {
    "revision": "05c8ff29e64c53fe2cd76393274e6f8c",
    "url": "/static/media/double-check.05c8ff29.svg"
  },
  {
    "revision": "acd8756cdb2832ad349e761198cc3c18",
    "url": "/static/media/navigation-dashboard-active.acd8756c.svg"
  },
  {
    "revision": "cd6968badf0870f71e556088d751fbfe",
    "url": "/static/media/navigation-dashboard.cd6968ba.svg"
  },
  {
    "revision": "d8c65bc22d288790d617354e01b794fa",
    "url": "/static/media/navigation-donations-active.d8c65bc2.svg"
  },
  {
    "revision": "7f1d81619a5a58aa4c6fb95d4457b1d8",
    "url": "/static/media/navigation-donations.7f1d8161.svg"
  },
  {
    "revision": "81d96dd99b9e1899ee29da0e7a89c621",
    "url": "/static/media/navigation-inventory-active.81d96dd9.svg"
  },
  {
    "revision": "b947bde5c77ba809b7e7ff95c987cdf4",
    "url": "/static/media/navigation-inventory.b947bde5.svg"
  },
  {
    "revision": "d3bd9502a40fe275193843093f626924",
    "url": "/static/media/navigation-logout-hover.d3bd9502.svg"
  },
  {
    "revision": "526f5964712ae37f8af8e3a418acf39b",
    "url": "/static/media/navigation-logout.526f5964.svg"
  },
  {
    "revision": "a1228ab5e7524c41bf66a1d91129c2c5",
    "url": "/static/media/navigation-market-active.a1228ab5.svg"
  },
  {
    "revision": "8af5e51644a27715846efefb8d31a9a2",
    "url": "/static/media/navigation-market.8af5e516.svg"
  },
  {
    "revision": "d745efe7f7f496e0a32c36b8c38b4bca",
    "url": "/static/media/navigation-transactions-active.d745efe7.svg"
  },
  {
    "revision": "0781b281aad25a9560b547a1a8786b3e",
    "url": "/static/media/navigation-transactions.0781b281.svg"
  },
  {
    "revision": "09e343d87e6aa35368e00178545878d6",
    "url": "/static/media/ndc-example.09e343d8.svg"
  },
  {
    "revision": "4ad956ce31743875240511b15293b870",
    "url": "/static/media/password-eye-show.4ad956ce.svg"
  },
  {
    "revision": "0263341561ef7018cc45634435b6a507",
    "url": "/static/media/password-eye.02633415.svg"
  },
  {
    "revision": "f2aac87a8c215866ac0fdea467caff3d",
    "url": "/static/media/print.f2aac87a.svg"
  },
  {
    "revision": "e3dec8b48ebe2a39b800752a2749e147",
    "url": "/static/media/randomize.e3dec8b4.svg"
  },
  {
    "revision": "77779a8dc02616d325e5f9dc2b915a60",
    "url": "/static/media/remove-urn-hover.77779a8d.svg"
  },
  {
    "revision": "6c5e6754a2140cec271ecff464ea90bd",
    "url": "/static/media/remove-urn.6c5e6754.svg"
  },
  {
    "revision": "57f7008268f74d047752a34ab2303dca",
    "url": "/static/media/save-logo.57f70082.svg"
  }
]);