#!/bin/bash -ex

cd $(dirname $0)

export VIRTUAL_HOST=save1.dev.adoriasoft.org
export VIRTUAL_PORT=3000
export REACT_APP_API='https://api.save1.dev.adoriasoft.org'
export REACT_APP_WEB3_PROVIDER='https://ropsten.infura.io/v3/b65f44abf0f84945bcc0126216e59664'

rm -rf save_pharma_frontend

(
  git clone https://frostdeacon:969631616Park@github.com/adoriasoft/save_pharma_frontend.git || true
  cd save_pharma_frontend
  npm install
  npm run build
)

cp -r ./save_pharma_frontend/build static
