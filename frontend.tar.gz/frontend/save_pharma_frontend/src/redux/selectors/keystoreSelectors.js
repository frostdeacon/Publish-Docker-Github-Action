import { createSelector } from 'reselect';

const keystoreReducer = (state) => state.keystore;

const selectAccount = createSelector(
  keystoreReducer,
  (reducer) => reducer.account,
);

const selectKeystore = createSelector(
  keystoreReducer,
  (reducer) => reducer.keystore,
);

const selectMnemonic = createSelector(
  keystoreReducer,
  (reducer) => reducer.mnemonic,
);

const selectPassword = createSelector(
  keystoreReducer,
  (reducer) => reducer.password,
);

export {
  selectAccount,
  selectKeystore,
  selectMnemonic,
  selectPassword,
};
