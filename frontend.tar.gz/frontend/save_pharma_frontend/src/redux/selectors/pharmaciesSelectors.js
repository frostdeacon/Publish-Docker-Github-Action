import { createSelector } from 'reselect';

const pharmaciesReducer = (state) => state.pharmacies;

const selectPharmacies = createSelector(
  pharmaciesReducer,
  (reducer) => reducer.pharmacies,
);

export {
  selectPharmacies,
};
