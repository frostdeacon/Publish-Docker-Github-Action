import { createSelector } from 'reselect';

const donationsReducer = (state) => state.donations;

const selectDonations = createSelector(
  donationsReducer,
  (reducer) => reducer.donations,
);

export {
  selectDonations,
};
