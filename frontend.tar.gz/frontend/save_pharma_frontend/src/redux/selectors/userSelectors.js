import { createSelector } from 'reselect';

const userReducer = (state) => state.user;

const selectUser = createSelector(
  userReducer,
  (reducer) => reducer.user,
);

const selectUserAddress = createSelector(
  selectUser,
  (user) => {
    if (!user) return null;
    return user.address;
  },
);

const selectUserRole = createSelector(
  selectUser,
  (user) => {
    if (!user) return null;
    return user.role;
  },
);

const selectIsSessionVerified = createSelector(
  userReducer,
  (reducer) => reducer.isSessionVerified,
);

export {
  selectUser,
  selectIsSessionVerified,
  selectUserAddress,
  selectUserRole,
};
