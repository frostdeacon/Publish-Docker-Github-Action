import { handleActions, combineActions } from 'redux-actions';
import { contractActions } from '../actions';

const initialState = {
  donations: [],
};

const donationsReducer = handleActions(
  {
    [combineActions(
      contractActions.saveMain.getDonorDonations.success,
      contractActions.saveMain.getPharmacistDonations.success,
    )]: (state, action) => ({
      ...state,
      donations: action.payload,
    }),
    [contractActions.saveMain.clearDonations]: (state) => ({
      ...state,
      donations: initialState.donations,
    }),
  },
  initialState,
);

export default donationsReducer;
