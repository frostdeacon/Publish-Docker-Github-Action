import { combineReducers } from 'redux';

import userReducer from './user';
import keystoreReducer from './keystore';
import errorsReducer from './errors';
import pharmaciesReducer from './pharmacies';
import donationsReducer from './donations';

const rootReducer = combineReducers({
  user: userReducer,
  keystore: keystoreReducer,
  errors: errorsReducer,
  pharmacies: pharmaciesReducer,
  donations: donationsReducer,
});

export default rootReducer;
