import { handleActions, combineActions } from 'redux-actions';
import { authActions, accountActions } from '../actions';

const initialState = {
  account: null,
  keystore: null,
  mnemonic: null,
  password: null,
};

const userReducer = handleActions(
  {
    [combineActions(
      authActions.signInKeystore.success,
      authActions.signUpKeystore.success,
      authActions.restoreKeystore.success,
    )]: (state, { payload }) => ({
      ...state,
      account: payload || state.account,
    }),
    [combineActions(
      accountActions.encryptAccount.success,
      accountActions.setKeystore,
    )]: (state, { payload }) => ({
      ...state,
      keystore: payload || state.keystore,
    }),
    [accountActions.clearKeystore]: (state) => ({
      ...state,
      keystore: initialState.keystore,
    }),
    [combineActions(
      accountActions.clearAccount,
      authActions.signOut.success,
    )]: (state) => ({
      ...state,
      account: initialState.account,
    }),
    [accountActions.clearMnemonic]: (state) => ({
      ...state,
      mnemonic: initialState.mnemonic,
    }),
    [authActions.setPassword]: (state, { payload }) => ({
      ...state,
      password: payload || state.password,
    }),
    [authActions.clearPassword]: (state) => ({
      ...state,
      password: initialState.password,
    }),
    [accountActions.setMnemonic]: (state, { payload }) => ({
      ...state,
      mnemonic: payload || state.mnemonic,
    }),
  },
  initialState,
);

export default userReducer;
