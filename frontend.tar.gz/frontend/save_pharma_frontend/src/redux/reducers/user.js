import { handleActions, combineActions } from 'redux-actions';
import { authActions } from '../actions';

const initialState = {
  user: null,
  isSessionVerified: false,
};

const userReducer = handleActions(
  {
    [combineActions(
      authActions.signIn.success,
      authActions.signUp.success,
      authActions.setAddress.success,
    )]: (state, action) => ({
      ...state,
      user: action.payload || state.user,
    }),
    [authActions.signOut.success]: (state) => ({
      ...state,
      user: initialState.user,
    }),
    [authActions.verifySession.success]: (state, action) => ({
      ...state,
      isSessionVerified: true,
      user: action.payload,
    }),
    [authActions.verifySession.failure]: (state) => ({
      ...state,
      isSessionVerified: true,
    }),
  },
  initialState,
);

export default userReducer;
