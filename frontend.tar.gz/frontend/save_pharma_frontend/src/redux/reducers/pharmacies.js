import { handleActions } from 'redux-actions';
import { contractActions } from '../actions';

const initialState = {
  pharmacies: [],
};

const pharmaciesReducer = handleActions(
  {
    [contractActions.saveMain.getPharmacies.success]: (state, action) => ({
      ...state,
      pharmacies: action.payload,
    }),
  },
  initialState,
);

export default pharmaciesReducer;
