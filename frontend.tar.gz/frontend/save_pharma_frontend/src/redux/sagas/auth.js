import {
  takeLatest,
  put,
  take,
  call,
  select,
} from 'redux-saga/effects';

import { authActions, accountActions } from '../actions';
import { keystoreSelectors } from '../selectors';
import { routes } from '../../router';
import api from '../../api';

import Blockchain from '../../utils/Blockchain';
import File from '../../utils/File';

function* signUpKeystoreWorker(action) {
  try {
    const { payload: password } = action;
    yield put(authActions.setPassword(password));
    const { payload: mnemonic } = yield take(accountActions.setMnemonic);
    yield take(accountActions.confirmMnemonic);
    const account = yield Blockchain.accountFromMnemonicAsync(mnemonic);
    yield put(authActions.signUpKeystore.success(account));
    yield put(accountActions.encryptAccount.call(password));
  } catch (error) {
    yield put(authActions.signUpKeystore.failure(error));
  }
}

function* signInKeystoreWorker(action) {
  try {
    const { keystoreFile, history } = action.payload;
    const keystore = yield File.readKeyFileAsync(keystoreFile);
    yield put(accountActions.setKeystore(JSON.parse(keystore)));
    const { payload: account } = yield take(authActions.signInKeystore.success);
    Blockchain.addAccountToWallet(account);
    yield call(history.push, routes.homeDashboard);
    yield put(accountActions.clearKeystore());
  } catch (error) {
    yield put(authActions.signInKeystore.failure(error));
  }
}

function* restoreKeystoreWorker(action) {
  try {
    const mnemonic = action.payload;
    const account = yield Blockchain.accountFromMnemonicAsync(mnemonic);
    yield put(authActions.restoreKeystore.success(account));
    const { payload: password } = yield take(authActions.setPassword);
    yield put(accountActions.encryptAccount.call(password));
    yield take(accountActions.encryptAccount.success);
    yield put(accountActions.clearAccount());
  } catch (error) {
    yield put(authActions.restoreKeystore.failure(error));
  }
}

function* signInWorker(action) {
  try {
    const { credentials, history } = action.payload;
    const { data: user } = yield call(api.post, '/signin', credentials);
    yield put(authActions.signIn.success(user));
    yield call(history.push, routes.homeDashboard);
  } catch (error) {
    yield put(authActions.signIn.failure(error.response));
  }
}

function* signUpWorker(action) {
  try {
    const credentials = action.payload;
    const { data: user } = yield call(api.post, '/signup', credentials);
    yield put(authActions.signUp.success(user));
  } catch (error) {
    yield put(authActions.signUp.failure(error.response));
  }
}

function* verifySessionWorker() {
  try {
    const { data: user } = yield call(api.get, '/check_session');
    yield put(authActions.verifySession.success(user));
  } catch (error) {
    if (error.response.status === 401) yield put(authActions.verifySession.failure());
  }
}

function* setAddressWorker() {
  try {
    const { address } = yield select(keystoreSelectors.selectAccount);
    const { data: user } = yield call(api.post, '/set_address', { address });
    yield put(authActions.setAddress.success(user));
  } catch (error) {
    yield put(authActions.setAddress.failure(error.response));
  }
}

function* signOutWorker(action) {
  try {
    const history = action.payload;
    yield call(api.post, '/logout');
    Blockchain.removeAccountsFromWallet();
    yield put(authActions.signOut.success());
    yield call(history.push, routes.signIn);
  } catch (error) {
    yield put(authActions.signOut.failure);
  }
}

function* signUpKeystoreWatcher() {
  yield takeLatest(authActions.signUpKeystore.call, signUpKeystoreWorker);
}

function* signInKeystoreWatcher() {
  yield takeLatest(authActions.signInKeystore.call, signInKeystoreWorker);
}

function* restoreKeystoreWatcher() {
  yield takeLatest(authActions.restoreKeystore.call, restoreKeystoreWorker);
}

function* signInWatcher() {
  yield takeLatest(authActions.signIn.call, signInWorker);
}

function* signUpWatcher() {
  yield takeLatest(authActions.signUp.call, signUpWorker);
}

function* verifySessionWatcher() {
  yield takeLatest(authActions.verifySession.call, verifySessionWorker);
}

function* setAddressWatcher() {
  yield takeLatest(authActions.setAddress.call, setAddressWorker);
}

function* signOutWatcher() {
  yield takeLatest(authActions.signOut.call, signOutWorker);
}

export {
  signUpKeystoreWatcher,
  signInKeystoreWatcher,
  restoreKeystoreWatcher,
  signInWatcher,
  signUpWatcher,
  verifySessionWatcher,
  setAddressWatcher,
  signOutWatcher,
};
