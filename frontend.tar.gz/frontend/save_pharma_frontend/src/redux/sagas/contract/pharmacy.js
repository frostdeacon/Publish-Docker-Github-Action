import {
  takeLatest,
  put,
  select,
  call,
} from 'redux-saga/effects';
import { contractActions } from '../../actions';
import { keystoreSelectors } from '../../selectors';
import { pharmacyCreator } from '../../../web3/contracts';
import { routes } from '../../../router';

function* addDonationWorker(action) {
  try {
    const { donation, contractAddress, history } = action.payload;
    const account = yield select(keystoreSelectors.selectAccount);
    const pharmacyContract = pharmacyCreator(contractAddress, account.address);
    yield pharmacyContract.methods.addDonation({ packages: donation }).send();
    yield put(contractActions.pharmacy.addDonation.success());
    yield call(history.push, routes.homeDashboard);
    yield call(history.push, routes.homeDonations);
    window.scrollTo(0, 0);
  } catch (error) {
    yield put(contractActions.pharmacy.addDonation.failure(error));
  }
}

function* approveDonationWorker(action) {
  try {
    const { pharmacyAddress, id } = action.payload;
    const account = yield select(keystoreSelectors.selectAccount);
    const pharmacyContract = pharmacyCreator(pharmacyAddress, account.address);
    yield pharmacyContract.methods.approveDonation(id, 1).send();
    yield put(contractActions.saveMain.getPharmacistDonations.call());
  } catch (error) {
    yield put(contractActions.pharmacy.approveDonation.failure(error));
  }
}

function* rejectDonationWorker(action) {
  try {
    const { pharmacyAddress, id } = action.payload;
    const account = yield select(keystoreSelectors.selectAccount);
    const pharmacyContract = pharmacyCreator(pharmacyAddress, account.address);
    yield pharmacyContract.methods.rejectDonation(id).send();
    yield put(contractActions.saveMain.getPharmacistDonations.call());
  } catch (error) {
    yield put(contractActions.pharmacy.rejectDonation.failure(error));
  }
}

function* addDonationWatcher() {
  yield takeLatest(contractActions.pharmacy.addDonation.call, addDonationWorker);
}

function* approveDonationWatcher() {
  yield takeLatest(contractActions.pharmacy.approveDonation.call, approveDonationWorker);
}

function* rejectDonationWatcher() {
  yield takeLatest(contractActions.pharmacy.rejectDonation.call, rejectDonationWorker);
}

export {
  addDonationWatcher,
  approveDonationWatcher,
  rejectDonationWatcher,
};
