import {
  takeLatest,
  put,
  select,
  take,
} from 'redux-saga/effects';
import { contractActions } from '../../actions';
import { saveMain, pharmacyCreator } from '../../../web3/contracts';
import { userSelectors } from '../../selectors';

function* getPharmaciesWorker() {
  try {
    const pharmacies = yield saveMain.methods.getPharmacies().call();
    yield put(contractActions.saveMain.getPharmacies.success(pharmacies));
  } catch (error) {
    yield put(contractActions.saveMain.getPharmacies.failure(error));
  }
}

function* getDonorDonationsWorker() {
  try {
    yield put(contractActions.saveMain.getPharmacies.call());
    const { payload: pharmacies } = yield take(contractActions.saveMain.getPharmacies.success);
    const address = yield select(userSelectors.selectUserAddress);
    const pharmaciesContracts = pharmacies.map((pharmacy) => pharmacyCreator(pharmacy, address));
    const donationsPromises = pharmaciesContracts.map(async (contract) => (
      contract.methods.getDonatorDonationsId().call()
        .then((ids) => {
          const promises = ids.map(async (id) => (
            contract.methods.getDonation(id).call()
          ));

          return Promise.all(promises);
        })
    ));
    const rawDonations = yield Promise.all(donationsPromises);
    const donations = rawDonations.reduce((result, pharmacyDonations) => (
      [...result, ...pharmacyDonations]
    ), []);
    yield put(contractActions.saveMain.getDonorDonations.success(donations));
  } catch (error) {
    yield put(contractActions.saveMain.getDonorDonations.failure(error));
  }
}

function* getPharmacistDonationsWorker() {
  try {
    yield put(contractActions.saveMain.getPharmacies.call());
    const { payload: pharmacies } = yield take(contractActions.saveMain.getPharmacies.success);
    const address = yield select(userSelectors.selectUserAddress);
    const pharmaciesContracts = pharmacies.map((pharmacy) => pharmacyCreator(pharmacy, address));
    const donationsPromises = pharmaciesContracts.map(async (contract) => (
      contract.methods.isDoctor(address).call().then((isDoctor) => {
        if (isDoctor) {
          return contract.methods.getDonations().call();
        }

        return null;
      })
    ));
    const rawDonations = yield Promise.all(donationsPromises);

    const donations = rawDonations.reduce((result, pharmacyDonations) => {
      if (!pharmacyDonations) return result;
      const filteredDonations = pharmacyDonations.filter((donation) => donation.status === '0');

      return [...result, ...filteredDonations];
    }, []);
    yield put(contractActions.saveMain.getPharmacistDonations.success(donations));
  } catch (error) {
    yield put(contractActions.saveMain.getPharmacistDonations.failure(error));
  }
}

function* getDonationsWorker() {
  const roles = {
    donor: contractActions.saveMain.getDonorDonations,
    pharmacist: contractActions.saveMain.getPharmacistDonations,
  };
  const userRole = yield select(userSelectors.selectUserRole);

  yield put(roles[userRole].call());
}

function* getDonationsWatcher() {
  yield takeLatest(contractActions.saveMain.getDonations, getDonationsWorker);
}

function* getPharmaciesWatcher() {
  yield takeLatest(contractActions.saveMain.getPharmacies.call, getPharmaciesWorker);
}

function* getDonorDonationsWatcher() {
  yield takeLatest(contractActions.saveMain.getDonorDonations.call, getDonorDonationsWorker);
}

function* getPharmacistDonationsWatcher() {
  yield takeLatest(
    contractActions.saveMain.getPharmacistDonations.call,
    getPharmacistDonationsWorker,
  );
}

export {
  getPharmaciesWatcher,
  getDonorDonationsWatcher,
  getPharmacistDonationsWatcher,
  getDonationsWatcher,
};
