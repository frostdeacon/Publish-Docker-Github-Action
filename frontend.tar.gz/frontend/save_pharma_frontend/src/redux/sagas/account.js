import {
  takeLatest,
  put,
  select,
} from 'redux-saga/effects';
import { accountActions } from '../actions';
import { keystoreSelectors } from '../selectors';
import Blockchain from '../../utils/Blockchain';

function* encryptAccountWorker(action) {
  try {
    const account = yield select(keystoreSelectors.selectAccount);
    const keystore = Blockchain.encryptAccount(account.privateKey, action.payload);

    yield put(accountActions.encryptAccount.success(keystore));
  } catch (error) {
    yield put(accountActions.encryptAccount.failure(error));
  }
}

function* encryptAccountWatcher() {
  yield takeLatest(accountActions.encryptAccount.call, encryptAccountWorker);
}

export {
  encryptAccountWatcher,
};
