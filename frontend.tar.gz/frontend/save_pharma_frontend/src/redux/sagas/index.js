import { all } from 'redux-saga/effects';
import * as authSagas from './auth';
import * as accountSagas from './account';
import * as contractSagas from './contract';

export default function* rootSaga() {
  yield all([
    // AUTH
    authSagas.signUpKeystoreWatcher(),
    authSagas.signInKeystoreWatcher(),
    authSagas.restoreKeystoreWatcher(),
    authSagas.signInWatcher(),
    authSagas.signUpWatcher(),
    authSagas.verifySessionWatcher(),
    authSagas.setAddressWatcher(),
    authSagas.signOutWatcher(),

    // ACCOUNT
    accountSagas.encryptAccountWatcher(),

    // CONTRACT
    // SAVE MAIN
    contractSagas.saveMain.getPharmaciesWatcher(),
    contractSagas.saveMain.getDonorDonationsWatcher(),
    contractSagas.saveMain.getPharmacistDonationsWatcher(),
    contractSagas.saveMain.getDonationsWatcher(),
    // PHARMACY
    contractSagas.pharmacy.addDonationWatcher(),
    contractSagas.pharmacy.approveDonationWatcher(),
    contractSagas.pharmacy.rejectDonationWatcher(),
  ]);
}
