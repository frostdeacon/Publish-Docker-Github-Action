import { createActions } from 'redux-actions';

export const {
  addDonation,
  approveDonation,
  rejectDonation,
} = createActions({
  ADD_DONATION: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  APPROVE_DONATION: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  REJECT_DONATION: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
});
