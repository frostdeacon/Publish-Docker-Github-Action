import { createActions } from 'redux-actions';

export const {
  getPharmacies,
  getDonorDonations,
  getPharmacistDonations,
  getDonations,
  clearDonations,
} = createActions({
  GET_PHARMACIES: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  GET_DONOR_DONATIONS: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  GET_PHARMACIST_DONATIONS: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  GET_DONATIONS: undefined,
  CLEAR_DONATIONS: undefined,
});
