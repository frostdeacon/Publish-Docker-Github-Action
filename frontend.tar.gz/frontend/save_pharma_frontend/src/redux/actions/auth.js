import { createActions } from 'redux-actions';

export const {
  signUpKeystore,
  signInKeystore,
  restoreKeystore,
  setPassword,
  clearPassword,
  signOut,
  signIn,
  signUp,
  verifySession,
  setAddress,
} = createActions({
  SIGN_UP_KEYSTORE: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  SIGN_IN_KEYSTORE: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  RESTORE_KEYSTORE: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  SET_PASSWORD: undefined,
  CLEAR_PASSWORD: undefined,
  SIGN_OUT: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  SIGN_IN: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  SIGN_UP: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  VERIFY_SESSION: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  SET_ADDRESS: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
});
