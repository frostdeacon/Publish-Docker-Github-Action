import { createActions } from 'redux-actions';

export const {
  encryptAccount,
  clearKeystore,
  clearAccount,
  clearMnemonic,
  setKeystore,
  setMnemonic,
  confirmMnemonic,
} = createActions({
  ENCRYPT_ACCOUNT: {
    call: undefined,
    success: undefined,
    failure: undefined,
  },
  CLEAR_KEYSTORE: undefined,
  CLEAR_ACCOUNT: undefined,
  CLEAR_MNEMONIC: undefined,
  SET_KEYSTORE: undefined,
  SET_MNEMONIC: undefined,
  CONFIRM_MNEMONIC: undefined,
});
