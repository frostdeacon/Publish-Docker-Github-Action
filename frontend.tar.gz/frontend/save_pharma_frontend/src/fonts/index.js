export default {
  regular: 'Lato Regular',
  medium: 'Rubik Medium',
  bold: 'Montserrat Bold',
};
