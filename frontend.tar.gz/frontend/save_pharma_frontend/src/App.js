// LIBS
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  HashRouter as Router,
  Switch,
  Route,
  Redirect,
} from 'react-router-dom';

// STYLED
import './App.css';

// ROUTER
import { routes } from './router';

// COMPONENTS
import ProtectedRoute from './components/ProtectedRoute';
import SignIn from './components/AuthComponents/SignIn';
import SignUp from './components/AuthComponents/SignUp';
import SignInKeystore from './components/AuthComponents/SignInKeystore';
import SignUpKeystore from './components/AuthComponents/SignUpKeystore';
import RecoveryKeystore from './components/AuthComponents/RecoveryKeystore';
import Root from './components/Root';
import Personal from './components/Personal';
import Home from './components/Home';

// REDUX
import { userSelectors } from './redux/selectors';
import { authActions } from './redux/actions';

function App() {
  const dispatch = useDispatch();
  const isSessionVerified = useSelector(userSelectors.selectIsSessionVerified);

  useEffect(() => {
    dispatch(authActions.verifySession.call());
  }, [dispatch]);

  return (
    isSessionVerified
      ? (
        <Router>
          <Switch>
            <Route path={routes.signIn} component={SignIn} />
            <Route path={routes.signUp} component={SignUp} />
            <ProtectedRoute path={routes.signInKeystore} component={SignInKeystore} />
            <ProtectedRoute path={routes.signUpKeystore} component={SignUpKeystore} />
            <ProtectedRoute path={routes.recoveryKeystore} component={RecoveryKeystore} />
            <ProtectedRoute path={routes.home} component={Home} />
            <ProtectedRoute path={routes.personal} component={Personal} />
            <Route exact path={routes.root} component={Root} />
            <Route path="*" render={() => <Redirect to="/" />} />
          </Switch>
        </Router>
      )
      : <div />
  );
}

export default App;
