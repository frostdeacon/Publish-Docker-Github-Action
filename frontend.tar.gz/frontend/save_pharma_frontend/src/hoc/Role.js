// LIBS
import React from 'react';
import { useSelector } from 'react-redux';

// REDUX
import { userSelectors } from '../redux/selectors';

const Role = ({ access, children }) => {
  const userRole = useSelector(userSelectors.selectUserRole);

  const returnChildren = () => {
    if (Array.isArray(access)) {
      return access.includes(userRole) ? <>{children}</> : null;
    }

    return access === userRole ? <>{children}</> : null;
  };

  return returnChildren();
};

export default Role;
