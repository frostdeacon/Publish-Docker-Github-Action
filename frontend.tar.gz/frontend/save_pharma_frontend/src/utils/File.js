export default class File {
  static readKeyFileAsync(keyFile) {
    return new Promise((res, rej) => {
      const reader = new FileReader();
      reader.onload = () => {
        res(reader.result);
      };
      reader.onerror = (error) => {
        rej(error);
      };
      reader.readAsText(keyFile);
    });
  }

  static saveKeyFile(keyJson) {
    const blob = new Blob([JSON.stringify(keyJson)], { type: 'text/json' });
    const a = document.createElement('a');
    a.style = 'display: none';
    const url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = 'Keystore.json';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }
}
