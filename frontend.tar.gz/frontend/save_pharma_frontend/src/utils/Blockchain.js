import web3 from '../web3';

const bip39 = require('bip39');
const HdKey = require('ethereumjs-wallet/hdkey');

export default class Blockchain {
  static generateMnemonic(strength = 256) {
    return bip39.generateMnemonic(strength);
  }

  static validateMnemonic(mnemonic) {
    return bip39.validateMnemonic(mnemonic);
  }

  static async mnemonicToSeedAsync(mnemonic) {
    const seed = await bip39.mnemonicToSeed(mnemonic);

    return seed;
  }

  static privateKeyHexFromSeed(seed) {
    return HdKey
      .fromMasterSeed(seed)
      .derivePath("m/44'/60'/0'/0")
      .deriveChild(0)
      .getWallet()
      .getPrivateKeyString();
  }

  static accountFromHexPrivateKey(hexPrivateKey) {
    return web3.eth.accounts.privateKeyToAccount(hexPrivateKey);
  }

  static decryptKeystore(keystore, password) {
    return web3.eth.accounts.decrypt(keystore, password);
  }

  static encryptAccount(privateKey, password) {
    return web3.eth.accounts.encrypt(privateKey, password);
  }

  static createSpacesInMnemonic(mnemonic, quantity = 4) {
    const spacesOnly = Array.from(new Array(quantity));

    const generateRandomIndex = () => (Math.round(Math.random() * 23));

    const randomIndexes = spacesOnly.reduce((result) => {
      let randomNumber = generateRandomIndex();
      while (result.includes(randomNumber)) {
        randomNumber = generateRandomIndex();
      }

      result.push(randomNumber);
      return result;
    }, []);

    return mnemonic.map((word, i) => (
      randomIndexes.includes(i) ? '' : word
    ));
  }

  static async accountFromMnemonicAsync(mnemonic = this.generateMnemonic()) {
    const seedBytes = await this.mnemonicToSeedAsync(mnemonic);
    const privateKeyHex = this.privateKeyHexFromSeed(seedBytes);
    const account = this.accountFromHexPrivateKey(privateKeyHex);

    return account;
  }

  static addAccountToWallet(account) {
    web3.eth.accounts.wallet.add(account);
  }

  static removeAccountsFromWallet() {
    web3.eth.accounts.wallet.clear();
  }
}
