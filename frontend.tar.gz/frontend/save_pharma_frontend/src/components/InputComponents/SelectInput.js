// LIBS
import React from 'react';

// STYLED
import { Inputs } from '../../styled/backbone';

const SelectInput = ({
  register,
  defaultValue,
  options,
  name,
  width = 350,
}) => (
  <Inputs.Select
    ref={register}
    defaultValue={defaultValue}
    name={name}
    width={width}
  >
    {
      options.map((option) => (
        <Inputs.Option
          key={option.value}
          value={option.value}
        >
          {option.key}
        </Inputs.Option>
      ))
    }
  </Inputs.Select>
);

export default SelectInput;
