import React, { useRef } from 'react';

import { Inputs } from '../../styled/backbone';

const FileInput = ({
  title,
  onChange,
}) => {
  const fileInput = useRef(null);

  const triggerFileInput = () => {
    fileInput.current.click();
  };

  return (
    <>
      <Inputs.File
        onChange={onChange}
        ref={fileInput}
      />
      <Inputs.Button type="button" onClick={triggerFileInput} value={title} />
    </>
  );
};

export default FileInput;
