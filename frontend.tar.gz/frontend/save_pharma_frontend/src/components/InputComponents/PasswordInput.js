import React, { useState } from 'react';

import { Inputs } from '../../styled/backbone';
import { Wrappers } from '../../styled';

import passwordEye from '../../assets/icons/password-eye.svg';
import passwordEyeShow from '../../assets/icons/password-eye-show.svg';

const PasswordInput = ({
  register,
  name,
  placeholder,
  required = false,
  pattern = false,
  validate = false,
  error = false,
  width = 350,
}) => {
  const [show, setShow] = useState(false);

  const handleShow = () => setShow(!show);

  return (
    <Wrappers.PasswordInput>
      <Inputs.Password
        name={name}
        placeholder={placeholder}
        ref={register({
          pattern,
          validate,
          required: required && 'This field is required',
        })}
        show={show}
        error={error}
        width={width}
      />
      <div />
      <Inputs.PasswordEye
        src={show ? passwordEyeShow : passwordEye}
        alt=""
        onClick={handleShow}
      />
    </Wrappers.PasswordInput>
  );
};

export default PasswordInput;
