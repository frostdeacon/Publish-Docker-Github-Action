import React, { useState } from 'react';
import { Inputs } from '../../styled/backbone';

const CounterInput = ({
  defaultValue = 1,
  register,
  name,
}) => {
  const [counter, setCounter] = useState(defaultValue);

  const increment = () => setCounter(counter + 1);

  const decrement = () => {
    if (counter <= 1) return;

    setCounter(counter - 1);
  };

  return (
    <Inputs.Counter>
      <Inputs.CounterAction onClick={decrement}>-</Inputs.CounterAction>
      <Inputs.CounterValue>{counter}</Inputs.CounterValue>
      <Inputs.CounterHiddenInput value={counter} ref={register} name={name} />
      <Inputs.CounterAction onClick={increment}>+</Inputs.CounterAction>
    </Inputs.Counter>
  );
};

export default CounterInput;
