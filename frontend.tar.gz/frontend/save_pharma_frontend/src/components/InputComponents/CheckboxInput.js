import React, { useState } from 'react';
import { Inputs } from '../../styled/backbone';

const CheckboxInput = ({
  register,
  name,
  required = false,
}) => {
  const [isChecked, setIsChecked] = useState(false);

  const handleCheck = () => setIsChecked(!isChecked);

  return (
    <div>
      <Inputs.HiddenCheckbox checked={isChecked} ref={register({ required })} name={name} />
      <Inputs.StyledCheckbox checked={isChecked} onClick={handleCheck}>
        <Inputs.CheckboxIcon viewBox="0 0 24 24">
          <polyline points="20 6 9 17 4 12" />
        </Inputs.CheckboxIcon>
      </Inputs.StyledCheckbox>
    </div>
  );
};

export default CheckboxInput;
