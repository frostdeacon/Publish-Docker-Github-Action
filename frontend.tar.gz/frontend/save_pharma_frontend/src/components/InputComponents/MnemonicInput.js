import React from 'react';
import { Inputs } from '../../styled/backbone';
import { Wrappers } from '../../styled';

const MnemonicInput = ({
  readOnly = false,
  index,
  defaultValue = '',
  register,
  name,
  validate = false,
  error,
  required = false,
}) => (
  <Wrappers.MnemonicInput>
    <Inputs.Mnemonic
      readOnly={readOnly}
      widePadding={index >= 9}
      defaultValue={defaultValue}
      ref={register && register({
        validate,
        required,
      })}
      name={name}
      error={error}
    />
    <span>{`${index + 1}.`}</span>
  </Wrappers.MnemonicInput>
);

export default MnemonicInput;
