import React from 'react';

import { Inputs } from '../../styled/backbone';
import { Wrappers } from '../../styled';

const TextInput = ({
  register,
  name,
  placeholder,
  required = false,
  pattern = false,
  width = 350,
  error,
}) => (
  <Wrappers.TextInput>
    <Inputs.Text
      name={name}
      placeholder={placeholder}
      width={width}
      error={error}
      ref={register({
        pattern,
        required: required && 'This field is required',
      })}
    />
    <div />
  </Wrappers.TextInput>
);

export default TextInput;
