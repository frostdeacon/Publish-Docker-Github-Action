// LIBS
import React, { useEffect } from 'react';
import useForm from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';

// REDUX
import { authActions } from '../../../redux/actions';
import { errorsSelectors } from '../../../redux/selectors';

// STYLED
import { Containers, Wrappers, SignIn as SignInStyled } from '../../../styled';

// COMPONENTS
import { PasswordInput, TextInput } from '../../InputComponents';

const SignIn = () => {
  const {
    handleSubmit,
    register,
    errors,
    setError,
  } = useForm();
  const dispatch = useDispatch();
  const history = useHistory();
  const apiError = useSelector(errorsSelectors.selectSignIn);

  useEffect(() => {
    if (apiError) {
      setError([
        {
          type: '',
          name: 'email',
          message: apiError.data.error,
        },
        {
          type: '',
          name: 'password',
          message: '',
        },
      ]);
    }
  }, [apiError, setError]);

  const onSubmit = (values) => {
    dispatch(authActions.signIn.call({
      credentials: values,
      history,
    }));
  };

  return (
    <Containers.SignIn>
      <Wrappers.SignIn>
        <SignInStyled.H2>Access to Save</SignInStyled.H2>
        <SignInStyled.H4>
          Please enter your credentials to sign in
        </SignInStyled.H4>
        <SignInStyled.InputsWrapper>
          <TextInput
            register={register}
            name="email"
            placeholder="Enter your email"
            required
            error={errors.email}
          />
          {
            errors.email
              && <SignInStyled.InputError>{errors.email.message}</SignInStyled.InputError>
          }
        </SignInStyled.InputsWrapper>
        <SignInStyled.InputsWrapper>
          <PasswordInput
            register={register}
            name="password"
            placeholder="Enter your password"
            required
            error={errors.password}
          />
          {
            errors.password && errors.password.message
              && <SignInStyled.InputError>{errors.password.message}</SignInStyled.InputError>
          }
        </SignInStyled.InputsWrapper>
        <SignInStyled.Submit
          value="ACCESS SAVE"
          onClick={handleSubmit(onSubmit)}
        />
      </Wrappers.SignIn>
    </Containers.SignIn>
  );
};

export default SignIn;
