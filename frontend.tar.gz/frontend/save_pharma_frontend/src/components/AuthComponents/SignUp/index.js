// LIBS
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

// REDUX
import { userSelectors } from '../../../redux/selectors';
import { authActions } from '../../../redux/actions';

// COMPONENTS
import EnterCredentials from './EnterCredentials';
import SignUpSuccess from './SignUpSuccess';

// STYLED
import { Containers, Wrappers } from '../../../styled';

const SignUp = () => {
  const dispatch = useDispatch();
  const user = useSelector(userSelectors.selectUser);

  useEffect(() => () => {
    if (user) dispatch(authActions.signOut.call());
  }, [dispatch, user]);

  return (
    <Containers.SignUp>
      <Wrappers.SignUp>
        {
          !user
            ? <EnterCredentials />
            : <SignUpSuccess />
        }
      </Wrappers.SignUp>
    </Containers.SignUp>
  );
};

export default SignUp;
