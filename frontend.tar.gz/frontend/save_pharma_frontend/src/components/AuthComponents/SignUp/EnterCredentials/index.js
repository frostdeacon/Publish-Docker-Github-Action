// LIBS
import React, { useEffect } from 'react';
import useForm from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

// STYLED
import { SignUp } from '../../../../styled';

// REDUX
import { authActions } from '../../../../redux/actions';
import { errorsSelectors } from '../../../../redux/selectors';

// COMPONENTS
import { TextInput, PasswordInput, SelectInput } from '../../../InputComponents';
import Validator from '../../../../utils/Validator';

const EnterCredentials = () => {
  const {
    handleSubmit,
    register,
    errors,
    getValues,
    setError,
  } = useForm();
  const dispatch = useDispatch();
  const apiError = useSelector(errorsSelectors.selectSignUp);

  useEffect(() => {
    if (apiError) {
      setError('email', '', apiError.data.error);
    }
  }, [apiError, setError]);

  const onSubmit = ({ email, password, role }) => {
    dispatch(authActions.signUp.call({ email, password, role }));
  };

  return (
    <>
      <SignUp.H2>Access to Save</SignUp.H2>
      <SignUp.H4>Please enter your email, create password and confirm it</SignUp.H4>
      <SignUp.InputsWrapper>
        <TextInput
          register={register}
          name="email"
          required
          error={errors.email}
          placeholder="Enter your email"
        />
        {
          errors.email
            && <SignUp.InputError>{errors.email.message}</SignUp.InputError>
        }
      </SignUp.InputsWrapper>
      <SignUp.InputsWrapper>
        <PasswordInput
          register={register}
          name="password"
          placeholder="Enter your password"
          error={errors.password}
          required
          pattern={{ value: Validator.password(), message: 'Password should contain at least 8 characters, 1 number, 1 lowercase and 1 uppercase' }}
        />
        {
          errors.password
            && <SignUp.InputError>{errors.password.message}</SignUp.InputError>
        }
      </SignUp.InputsWrapper>
      <SignUp.InputsWrapper>
        <PasswordInput
          register={register}
          name="confirm"
          placeholder="Confirm your password"
          error={errors.confirm}
          required
          validate={(value) => value === getValues().password || 'Password doesn\'t match'}
        />
        {
          errors.confirm
            && <SignUp.InputError>{errors.confirm.message}</SignUp.InputError>
        }
      </SignUp.InputsWrapper>
      <SignUp.InputsWrapper>
        <SelectInput
          name="role"
          register={register}
          options={[{
            key: 'Donor',
            value: 'donor',
          }, {
            key: 'Pharmacist',
            value: 'pharmacist',
          }]}
          defaultValue="donor"
        />
      </SignUp.InputsWrapper>
      <SignUp.Submit
        onClick={handleSubmit(onSubmit)}
        value="CREATE ACCOUNT"
      />
    </>
  );
};

export default EnterCredentials;
