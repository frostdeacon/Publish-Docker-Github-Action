// LIBS
import React from 'react';
import { useHistory } from 'react-router-dom';

// ROUTER
import { routes } from '../../../../router';

// STYLED
import { SignUp } from '../../../../styled';
import DoubleCheckImg from '../../../../assets/icons/double-check.svg';

const SignUpSuccess = () => {
  const history = useHistory();

  const toSignIn = () => {
    history.push(routes.signIn);
  };

  return (
    <>
      <SignUp.SuccessImg
        src={DoubleCheckImg}
      />
      <SignUp.SuccessH3>Registration completed</SignUp.SuccessH3>
      <SignUp.SuccessH4>
        Now you can proceed to Sign in page
      </SignUp.SuccessH4>
      <SignUp.SuccessPaleButton
        onClick={toSignIn}
        value="TO SIGN IN"
      />
    </>
  );
};

export default SignUpSuccess;
