// LIBS
import React from 'react';
import { useSelector } from 'react-redux';

// STYLED
import { Wrappers, Containers, SignInKeystore as SignInKeystoreStyles } from '../../../styled';

// REDUX
import { keystoreSelectors } from '../../../redux/selectors';

// COMPONENTS
import UploadKeystore from './UploadKeystore';
import EnterPassword from './EnterPassword';

const SignInKeystore = () => {
  const keystore = useSelector(keystoreSelectors.selectKeystore);

  return (
    <Containers.SignInKeystore>
      <Wrappers.SignInKeystore>
        <SignInKeystoreStyles.IndexH2>Access to Save</SignInKeystoreStyles.IndexH2>
        {
          !keystore
            ? <UploadKeystore />
            : <EnterPassword />
        }
      </Wrappers.SignInKeystore>
    </Containers.SignInKeystore>
  );
};

export default SignInKeystore;
