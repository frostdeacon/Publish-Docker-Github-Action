// LIBS
import React from 'react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';

// ROUTER
import { routes } from '../../../../router';

// COMPONENTS
import { FileInput } from '../../../InputComponents';

// REDUX
import { authActions } from '../../../../redux/actions';

// STYLED
import { SignInKeystore } from '../../../../styled';

const UploadKeystore = () => {
  const history = useHistory();
  const dispatch = useDispatch();

  const onSubmit = (e) => {
    dispatch(authActions.signInKeystore.call({ keystoreFile: e.target.files[0], history }));
  };

  return (
    <>
      <SignInKeystore.UploadKeystoreH4>
        Please upload your keystore file to sign in the platform
      </SignInKeystore.UploadKeystoreH4>
      <FileInput
        onChange={onSubmit}
        title="UPLOAD KEYSTORE FILE"
      />
      <SignInKeystore.UploadKeystoreLostLink
        to={routes.recoveryKeystore}
      >
        Lost your keystore file?
      </SignInKeystore.UploadKeystoreLostLink>
      <SignInKeystore.UploadKeystoreFooter>
        Don&apos;t have a keystore file?&nbsp;
        <SignInKeystore.UploadKeystoreSignupLink
          to={routes.signUpKeystore}
        >
          Sign up
        </SignInKeystore.UploadKeystoreSignupLink>
        &nbsp;to create it
      </SignInKeystore.UploadKeystoreFooter>
    </>
  );
};

export default UploadKeystore;
