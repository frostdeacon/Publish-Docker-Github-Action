// LIBS
import React from 'react';
import useForm from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

// COMPONENTS
import { PasswordInput } from '../../../InputComponents';

// REDUX
import { authActions, accountActions } from '../../../../redux/actions';
import { keystoreSelectors, userSelectors } from '../../../../redux/selectors';

// STYLED
import { SignInKeystore } from '../../../../styled';

// UTILS
import Blockchain from '../../../../utils/Blockchain';

const EnterPassword = () => {
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    errors,
    setError,
  } = useForm();

  const keystore = useSelector(keystoreSelectors.selectKeystore);
  const userAddress = useSelector(userSelectors.selectUserAddress);

  const clearKeystore = () => dispatch(accountActions.clearKeystore());

  const onSubmit = ({ password }) => {
    try {
      const account = Blockchain.decryptKeystore(keystore, password);
      if (account.address === userAddress) {
        dispatch(authActions.signInKeystore.success(account));
      } else {
        setError('password', 'keystore', 'Wrong keystore');
      }
    } catch (e) {
      setError('password', 'validate', 'Wrong password');
    }
  };

  return (
    <>
      <SignInKeystore.EnterPasswordH4>
        Enter the password for your keystore file
      </SignInKeystore.EnterPasswordH4>
      <SignInKeystore.EnterPasswordForm onSubmit={handleSubmit(onSubmit)}>
        <PasswordInput
          register={register}
          name="password"
          placeholder="Enter your password"
          required
          error={errors.password}
        />
        {
          errors.password
            && (
              <SignInKeystore.EnterPasswordError>
                {`Error: ${errors.password.message}. Try again`}
              </SignInKeystore.EnterPasswordError>
            )
        }
        <SignInKeystore.EnterPasswordSubmit value="ACCESS SAVE" />
        {
          errors.password && errors.password.type === 'keystore'
            && (
              <SignInKeystore.BackToUploadPaleButton
                value="UPLOAD NEW KEYSTORE"
                onClick={clearKeystore}
              />
            )
        }
      </SignInKeystore.EnterPasswordForm>
    </>
  );
};

export default EnterPassword;
