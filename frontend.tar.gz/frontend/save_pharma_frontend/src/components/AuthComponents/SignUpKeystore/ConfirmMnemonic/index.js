// LIBS
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useForm from 'react-hook-form';

// REDUX
import { accountActions } from '../../../../redux/actions';
import { keystoreSelectors } from '../../../../redux/selectors';

// STYLED
import { Wrappers, SignUpKeystore } from '../../../../styled';

// UTILS
import Blockchain from '../../../../utils/Blockchain';

// COMPONENTS
import { MnemonicInput } from '../../../InputComponents';

const ConfirmMnemonic = () => {
  const dispatch = useDispatch();
  const mnemonic = useSelector(keystoreSelectors.selectMnemonic).split(' ');
  const [mnemonicWithSpaces] = useState(Blockchain.createSpacesInMnemonic(mnemonic));
  const { register, handleSubmit, errors } = useForm();

  const confirmMnemonic = () => {
    dispatch(accountActions.confirmMnemonic());
  };

  return (
    <Wrappers.SignUpKeystoreConfirmMnemonic>
      <SignUpKeystore.ConfirmMnemonicH2>Recovery key verification</SignUpKeystore.ConfirmMnemonicH2>
      <SignUpKeystore.ConfirmMnemonicH5>
        Please fill out the empty fields below
        to make sure you did it right
      </SignUpKeystore.ConfirmMnemonicH5>
      <SignUpKeystore.MnemonicWrapper>
        {
          mnemonicWithSpaces.map((word, i) => (
            <MnemonicInput
              // Words can be repeated in rare cases
              // eslint-disable-next-line
              key={`${word}_${i}`}
              readOnly={word !== ''}
              index={i}
              name={i}
              register={register}
              error={errors[i]}
              defaultValue={word}
              validate={(value) => value === mnemonic[i] || 'Word doesn\'t match'}
            />
          ))
        }
      </SignUpKeystore.MnemonicWrapper>
      <SignUpKeystore.ConfirmMnemonicButton lg onClick={handleSubmit(confirmMnemonic)} value="VERIFY RECOVERY KEY" />
    </Wrappers.SignUpKeystoreConfirmMnemonic>
  );
};

export default ConfirmMnemonic;
