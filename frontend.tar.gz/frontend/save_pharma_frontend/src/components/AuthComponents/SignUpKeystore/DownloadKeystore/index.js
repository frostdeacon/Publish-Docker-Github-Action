// LIBS
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';

// ROUTER
import { routes } from '../../../../router';

// REDUX
import { keystoreSelectors } from '../../../../redux/selectors';
import { authActions } from '../../../../redux/actions';

// UTILS
import File from '../../../../utils/File';

// STYLED
import { Wrappers, SignUpKeystore } from '../../../../styled';
import DoubleCheckImg from '../../../../assets/icons/double-check.svg';

const DownloadKeystore = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [isDownloaded, setIsDownloaded] = useState(false);
  const keystore = useSelector(keystoreSelectors.selectKeystore);

  const toSignIn = () => {
    history.push(routes.signInKeystore);
  };

  const downloadKeystore = () => {
    if (!isDownloaded) {
      dispatch(authActions.setAddress.call());
      setIsDownloaded(true);
    }
    File.saveKeyFile(keystore);
  };

  return (
    <Wrappers.SignUpKeystoreDownloadKeystoreOuter>
      <Wrappers.SignUpKeystoreDownloadKeystore>
        <SignUpKeystore.DownloadKeystoreImg
          src={DoubleCheckImg}
          alt=""
        />
        <SignUpKeystore.DownloadKeystoreH3>Generation completed</SignUpKeystore.DownloadKeystoreH3>
        <SignUpKeystore.DownloadKeystoreH4>
          Now you can save your keystore file
        </SignUpKeystore.DownloadKeystoreH4>
        <SignUpKeystore.DownloadKeystoreButton onClick={downloadKeystore} value="DOWNLOAD KEYSTORE FILE" />
        {
          isDownloaded && <SignUpKeystore.DownloadKeystorePaleButton onClick={toSignIn} value="SIGN IN TO SAVE" />
        }
      </Wrappers.SignUpKeystoreDownloadKeystore>
      <SignUpKeystore.DownloadKeystoreReminder>
        <span>DO NOT FORGET</span>
        &nbsp;to save your password. You will need this
      </SignUpKeystore.DownloadKeystoreReminder>
      <SignUpKeystore.DownloadKeystoreReminder>
        <span>Password + Keystore</span>
        &nbsp;File to unlock your wallet.
      </SignUpKeystore.DownloadKeystoreReminder>
    </Wrappers.SignUpKeystoreDownloadKeystoreOuter>
  );
};

export default DownloadKeystore;
