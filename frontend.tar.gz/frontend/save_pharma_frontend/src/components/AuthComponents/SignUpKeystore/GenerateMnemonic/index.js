// LIBS
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

// REDUX
import { accountActions } from '../../../../redux/actions';

// UTILS
import Blockchain from '../../../../utils/Blockchain';

// COMPONENTS
import { MnemonicInput } from '../../../InputComponents';

// STYLED
import RandomImg from '../../../../assets/icons/randomize.svg';
import PrintImg from '../../../../assets/icons/print.svg';
import { Wrappers, SignUpKeystore } from '../../../../styled';

const GenerateMnemonic = () => {
  const [mnemonic, setMnemonic] = useState(Blockchain.generateMnemonic().split(' '));
  const dispatch = useDispatch();

  const generateMnemonic = () => {
    const mnemonicString = Blockchain.generateMnemonic();
    setMnemonic(mnemonicString.split(' '));
  };

  const confirmMnemonic = () => {
    dispatch(accountActions.setMnemonic(mnemonic.join(' ')));
  };

  return (
    <Wrappers.SignUpKeystoreGenerateMnemonic>
      <SignUpKeystore.GenerateMnemonicH2>Your recovery key</SignUpKeystore.GenerateMnemonicH2>
      <SignUpKeystore.GenerateMnemonicH5>
        Write down these 24 words in this exact order.
        Keep your recovery key and don’t share this list with anyone.
        If you lose it, you will irrevocably lose access to your account.
      </SignUpKeystore.GenerateMnemonicH5>
      <SignUpKeystore.MnemonicActions>
        <SignUpKeystore.MnemonicAction onClick={generateMnemonic}>
          <SignUpKeystore.MnemonicActionImage
            src={RandomImg}
            alt=""
          />
          <SignUpKeystore.MnemonicActionTitle>RANDOMIZE</SignUpKeystore.MnemonicActionTitle>
        </SignUpKeystore.MnemonicAction>
        <SignUpKeystore.MnemonicAction>
          <SignUpKeystore.MnemonicActionImage
            src={PrintImg}
            alt=""
          />
          <SignUpKeystore.MnemonicActionTitle>
            PRINT RECOVERY PHRASE
          </SignUpKeystore.MnemonicActionTitle>
        </SignUpKeystore.MnemonicAction>
      </SignUpKeystore.MnemonicActions>
      <SignUpKeystore.MnemonicWrapper>
        {
          mnemonic.map((word, i) => (
            <MnemonicInput
              // Words can be repeated in rare cases
              // eslint-disable-next-line
              key={`${word}_${i}`}
              readOnly
              defaultValue={word}
              index={i}
            />
          ))
        }
      </SignUpKeystore.MnemonicWrapper>
      <SignUpKeystore.GenerateMnemonicButton lg value="I WROTE DOWN THE RECOVERY KEY" onClick={confirmMnemonic} />
    </Wrappers.SignUpKeystoreGenerateMnemonic>
  );
};

export default GenerateMnemonic;
