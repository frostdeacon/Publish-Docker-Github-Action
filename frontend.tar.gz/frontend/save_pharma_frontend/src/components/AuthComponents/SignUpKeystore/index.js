// LIBS
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Redirect } from 'react-router-dom';

// REDUX
import { accountActions, authActions } from '../../../redux/actions';
import { keystoreSelectors, userSelectors } from '../../../redux/selectors';

// STYLED
import { Containers } from '../../../styled';

// ROUTER
import { routes } from '../../../router';

// COMPONENTS
import CreatePassword from './CreatePassword';
import GenerateMnemonic from './GenerateMnemonic';
import ConfirmMnemonic from './ConfirmMnemonic';
import DownloadKeystore from './DownloadKeystore';

const SignUpKeystore = () => {
  const dispatch = useDispatch();

  const keystore = useSelector(keystoreSelectors.selectKeystore);
  const mnemonic = useSelector(keystoreSelectors.selectMnemonic);
  const password = useSelector(keystoreSelectors.selectPassword);
  const address = useSelector(userSelectors.selectUserAddress);

  useEffect(() => () => {
    dispatch(accountActions.clearKeystore());
    dispatch(accountActions.clearMnemonic());
    dispatch(accountActions.clearAccount());
    dispatch(authActions.clearPassword());
  }, [dispatch]);

  return (
    <Containers.SignUpKeystore>
      {
        !password && !mnemonic && !keystore && <CreatePassword />
      }
      {
        password && !mnemonic && !keystore && <GenerateMnemonic />
      }
      {
        password && mnemonic && !keystore && <ConfirmMnemonic />
      }
      {
        password && mnemonic && keystore && <DownloadKeystore />
      }
      {
        address && !(password && mnemonic && keystore) && <Redirect to={routes.signInKeystore} />
      }
    </Containers.SignUpKeystore>
  );
};

export default SignUpKeystore;
