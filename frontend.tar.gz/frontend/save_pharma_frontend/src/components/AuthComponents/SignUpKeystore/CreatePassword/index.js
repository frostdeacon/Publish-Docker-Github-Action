// LIBS
import React from 'react';
import useForm from 'react-hook-form';
import { useDispatch } from 'react-redux';

// REDUX
import { authActions } from '../../../../redux/actions';

// ROUTER
import { routes } from '../../../../router';

// STYLED
import { Wrappers, SignUpKeystore } from '../../../../styled';

// UTILS
import Validator from '../../../../utils/Validator';

// COMPONENTS
import { PasswordInput } from '../../../InputComponents';

const CreatePassword = () => {
  const dispatch = useDispatch();
  const { register, errors, handleSubmit } = useForm();

  const signUp = (values) => {
    dispatch(authActions.signUpKeystore.call(values.password));
  };

  return (
    <Wrappers.SignUpKeystoreCreatePasswordOuter>
      <Wrappers.SignUpKeystoreCreatePassword>
        <SignUpKeystore.CreatePasswordH2>
          Get an access to start donation
        </SignUpKeystore.CreatePasswordH2>
        <SignUpKeystore.CreatePasswordH4>Create a password first</SignUpKeystore.CreatePasswordH4>
        <SignUpKeystore.CreatePasswordForm onSubmit={handleSubmit(signUp)}>
          <PasswordInput
            register={register}
            name="password"
            error={errors.password}
            pattern={{ value: Validator.password(), message: 'Password should contain at least 8 characters, 1 number, 1 lowercase and 1 uppercase' }}
            required
            placeholder="Please enter at least 8 characters"
          />
          {
            errors.password
            && (
              <>
                <SignUpKeystore.CreatePasswordError>
                  Error: Password should contain at least 8 characters,
                </SignUpKeystore.CreatePasswordError>
                <SignUpKeystore.CreatePasswordError>
                  1 number, 1 lowercase and 1 uppercase
                </SignUpKeystore.CreatePasswordError>
              </>
            )
          }
          <SignUpKeystore.CreatePasswordSubmit value="NEXT STEP" />
        </SignUpKeystore.CreatePasswordForm>
        <SignUpKeystore.CreatePasswordFooter>
          Already have an access?&nbsp;
          <SignUpKeystore.CreatePasswordFooterLink
            to={routes.signInKeystore}
          >
            Sign in
          </SignUpKeystore.CreatePasswordFooterLink>
          &nbsp;now
        </SignUpKeystore.CreatePasswordFooter>
      </Wrappers.SignUpKeystoreCreatePassword>
      <SignUpKeystore.CreatePasswordReminder>
        <span>DO NOT FORGET</span>
        &nbsp;to save your password. You will need this
      </SignUpKeystore.CreatePasswordReminder>
      <SignUpKeystore.CreatePasswordReminder>
        <span>Password + Keystore</span>
        &nbsp;File to unlock your wallet.
      </SignUpKeystore.CreatePasswordReminder>
    </Wrappers.SignUpKeystoreCreatePasswordOuter>
  );
};

export default CreatePassword;
