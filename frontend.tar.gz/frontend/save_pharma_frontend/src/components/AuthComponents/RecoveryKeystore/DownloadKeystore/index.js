// LIBS
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useSelector } from 'react-redux';

// REDUX
import { keystoreSelectors } from '../../../../redux/selectors';

// ROUTER
import { routes } from '../../../../router';

// STYLED
import { Wrappers, RecoveryKeystore } from '../../../../styled';
import DoubleCheckImg from '../../../../assets/icons/double-check.svg';

// UTILS
import File from '../../../../utils/File';

const DownloadKeystore = () => {
  const history = useHistory();
  const [isDownloaded, setIsDownloaded] = useState(false);
  const keystore = useSelector(keystoreSelectors.selectKeystore);

  const toSignIn = () => {
    history.push(routes.signInKeystore);
  };

  const downloadKeystore = () => {
    if (!isDownloaded) setIsDownloaded(true);
    File.saveKeyFile(keystore);
  };

  return (
    <Wrappers.RecoveryKeystoreDownloadKeystore>
      <RecoveryKeystore.DownloadKeystoreIcon
        src={DoubleCheckImg}
      />
      <RecoveryKeystore.DownloadKeystoreH3>Congratulations!</RecoveryKeystore.DownloadKeystoreH3>
      <RecoveryKeystore.DownloadKeystoreH4>
        Save your new keystore file
        and be careful next time
      </RecoveryKeystore.DownloadKeystoreH4>
      <RecoveryKeystore.DownloadKeystoreButton
        onClick={downloadKeystore}
        value="DOWNLOAD KEYSTORE FILE"
      />
      {
        isDownloaded && <RecoveryKeystore.DownloadKeystoreSignInButton onClick={toSignIn} value="SIGN IN TO SAVE" />
      }
    </Wrappers.RecoveryKeystoreDownloadKeystore>
  );
};

export default DownloadKeystore;
