// LIBS
import React from 'react';
import useForm from 'react-hook-form';
import { useDispatch } from 'react-redux';

// REDUX
import { authActions } from '../../../../redux/actions';

// STYLED
import { Wrappers, RecoveryKeystore } from '../../../../styled';

// COMPONENTS
import { MnemonicInput } from '../../../InputComponents';

// UTILS
import Blockchain from '../../../../utils/Blockchain';

const EnterMnemonic = () => {
  const { register, errors, handleSubmit } = useForm();
  const dispatch = useDispatch();

  const onSubmit = (values) => {
    const mnemonic = Object.values(values).join(' ');

    if (Blockchain.validateMnemonic(mnemonic)) {
      dispatch(authActions.restoreKeystore.call(mnemonic));
    }
  };

  return (
    <Wrappers.RecoveryKeystoreEnterMnemonic>
      <RecoveryKeystore.EnterMnemonicH2>Recover keystore file</RecoveryKeystore.EnterMnemonicH2>
      <RecoveryKeystore.EnterMnemonicH5>
        Write down 24 words of your recovery phrase
        in exact order
      </RecoveryKeystore.EnterMnemonicH5>
      <RecoveryKeystore.EnterMnemonicWrapper>
        {
          Array.from(new Array(24)).map((undef, i) => (
            <MnemonicInput
              // Words can be repeated in rare cases
              // eslint-disable-next-line
              key={i}
              index={i}
              name={i}
              register={register}
              error={errors[i]}
              required
            />
          ))
        }
      </RecoveryKeystore.EnterMnemonicWrapper>
      <RecoveryKeystore.EnterMnemonicButton lg value="RECOVER KEYSTORE FILE" onClick={handleSubmit(onSubmit)} />
    </Wrappers.RecoveryKeystoreEnterMnemonic>
  );
};

export default EnterMnemonic;
