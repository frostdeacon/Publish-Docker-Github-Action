// LIBS
import React from 'react';
import useForm from 'react-hook-form';
import { useDispatch } from 'react-redux';

// REDUX
import { authActions } from '../../../../redux/actions';

// UTILS
import Validator from '../../../../utils/Validator';

// COMPONENTS
import { PasswordInput } from '../../../InputComponents';

// STYLED
import { Wrappers, RecoveryKeystore } from '../../../../styled';
import DoubleCheckImg from '../../../../assets/icons/double-check.svg';

const EnterPassword = () => {
  const { handleSubmit, register, errors } = useForm();
  const dispatch = useDispatch();

  const setNewPassword = ({ password }) => {
    dispatch(authActions.setPassword(password));
  };

  return (
    <Wrappers.RecoveryKeystoreEnterPassword>
      <RecoveryKeystore.EnterPasswordIcon
        src={DoubleCheckImg}
      />
      <RecoveryKeystore.EnterPasswordH3>
        Recovery completed
      </RecoveryKeystore.EnterPasswordH3>
      <RecoveryKeystore.EnterPasswordH4>
        Create a new password
        for your new keystore file
      </RecoveryKeystore.EnterPasswordH4>
      <RecoveryKeystore.EnterPasswordForm onSubmit={handleSubmit(setNewPassword)}>
        <PasswordInput
          register={register}
          name="password"
          error={errors.password}
          placeholder="Please enter at least 8 characters"
          pattern={{ value: Validator.password(), message: 'Password should contain at least 8 characters, 1 number, 1 lowercase and 1 uppercase' }}
          required
        />
        <RecoveryKeystore.EnterPasswordSubmit value="GET NEW KEYSTORE FILE" />
      </RecoveryKeystore.EnterPasswordForm>
    </Wrappers.RecoveryKeystoreEnterPassword>
  );
};

export default EnterPassword;
