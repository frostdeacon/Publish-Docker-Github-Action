// LIBS
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

// COMPONENTS
import EnterMnemonic from './EnterMnemonic';
import EnterPassword from './EnterPassword';
import DownloadKeystore from './DownloadKeystore';

// STYLED
import { Containers } from '../../../styled';

// REDUX
import { accountActions, authActions } from '../../../redux/actions';
import { keystoreSelectors } from '../../../redux/selectors';

const RecoveryKeystore = () => {
  const dispatch = useDispatch();
  const account = useSelector(keystoreSelectors.selectAccount);
  const keystore = useSelector(keystoreSelectors.selectKeystore);

  useEffect(() => () => {
    dispatch(accountActions.clearKeystore());
    dispatch(authActions.clearPassword());
  }, [dispatch]);

  return (
    <Containers.RecoveryKeystore>
      {
        !account && !keystore && <EnterMnemonic />
      }
      {
        account && !keystore && <EnterPassword />
      }
      {
        !account && keystore && <DownloadKeystore />
      }
    </Containers.RecoveryKeystore>
  );
};

export default RecoveryKeystore;
