// LIBS
import React from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';

// STYLED
import { Containers, Wrappers } from '../../styled';
import fonts from '../../fonts';
import colors from '../../colors';

// COMPONENTS
import HomeNavigation from './HomeNavigation';
import HomeHeader from './HomeHeader';
import Donations from './Donations';

// ROUTER
import { routes } from '../../router';

const MockTitle = () => (
  <h1
    style={{
      fontSize: '40px',
      lineHeight: '46px',
      fontFamily: fonts.bold,
      color: colors.mainBlack,
    }}
  >
    Content Expected...
  </h1>
);

const Home = () => (
  <Containers.Home>
    <HomeNavigation />
    <Wrappers.HomeSection>
      <HomeHeader />
      <Wrappers.HomeContent>
        <Switch>
          <Route path={routes.homeDashboard} component={MockTitle} />
          <Route path={routes.homeDonations} component={Donations} />
          <Route path={routes.homeActiveInventory} component={MockTitle} />
          <Route path={routes.homeTransactions} component={MockTitle} />
          <Route path={routes.homeSaveCoinMarket} component={MockTitle} />
          <Route exact path={routes.home} render={() => <Redirect to="/home/dashboard" />} />
          <Route path={routes.homeWildcard} render={() => <Redirect to="/home/dashboard" />} />
        </Switch>
      </Wrappers.HomeContent>
    </Wrappers.HomeSection>
  </Containers.Home>
);

export default Home;
