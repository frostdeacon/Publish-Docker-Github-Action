// LIBS
import React, { useState } from 'react';
import { useSelector } from 'react-redux';

// STYLED
import { Wrappers, Donations as DonationsStyled } from '../../../styled';

// COMPONENTS
import AddDonations from './AddDonations';
import DonationsList from './DonationsList';
import NoAddress from './NoAddress';
import NoKeystore from './NoKeystore';

// REDUX
import { userSelectors, keystoreSelectors } from '../../../redux/selectors';

const Donations = () => {
  const [showDonationForm, setShowDonationForm] = useState(false);
  const userAddress = useSelector(userSelectors.selectUserAddress);
  const userAccount = useSelector(keystoreSelectors.selectAccount);

  const handleShowDonationForm = () => setShowDonationForm(true);

  const handleShowDonationsList = () => setShowDonationForm(false);

  const renderChildren = () => {
    if (!userAddress) return <NoAddress />;
    if (!showDonationForm) return <DonationsList showDonationForm={handleShowDonationForm} />;

    return userAccount
      ? <AddDonations showDonationsList={handleShowDonationsList} />
      : <NoKeystore />;
  };

  return (
    <Wrappers.Donations>
      <DonationsStyled.AddH1>List of Donated Drugs</DonationsStyled.AddH1>
      {
        renderChildren()
      }
    </Wrappers.Donations>
  );
};

export default Donations;
