// LIBS
import React from 'react';
import { useHistory } from 'react-router-dom';

// ROUTER
import { routes } from '../../../../router';

// STYLED
import { Donations } from '../../../../styled';

const NoAddress = () => {
  const history = useHistory();

  const toKeystoreSignUp = () => history.push(routes.signUpKeystore);

  return (
    <>
      <Donations.NoAddressH3>
        Seems like you don&apos;t have a keystore yet.
      </Donations.NoAddressH3>
      <Donations.NoAddressPaleButton
        value="GENERATE KEYSTORE"
        onClick={toKeystoreSignUp}
      />
    </>
  );
};

export default NoAddress;
