// LIBS
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

// STYLED
import { Donations } from '../../../../styled';

// COMPONENTS
import Donation from './Donation';

// HOC
import RoleHOC from '../../../../hoc/Role';

// REDUX
import { contractActions } from '../../../../redux/actions';
import { donationsSelectors } from '../../../../redux/selectors';

const DonationsList = ({ showDonationForm }) => {
  const dispatch = useDispatch();
  const donations = useSelector(donationsSelectors.selectDonations);

  useEffect(() => {
    dispatch(contractActions.saveMain.getDonations());
  }, [dispatch]);

  useEffect(() => () => {
    dispatch(contractActions.saveMain.clearDonations());
  }, [dispatch]);

  return (
    <>
      <RoleHOC access="donor">
        <Donations.ListAddItemButton
          value="ADD DONATION"
          onClick={showDonationForm}
        />
      </RoleHOC>
      {
        donations.length > 0 && donations.map((donation, i) => (
          <Donation
            // no unique id for donation
            // eslint-disable-next-line
            key={i}
            donation={donation}
          />
        ))
      }
    </>
  );
};

export default DonationsList;
