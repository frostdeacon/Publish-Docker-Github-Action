// LIBS
import React from 'react';

// STYLED
import { Wrappers, Donations } from '../../../../../../styled';

const DonationItem = ({
  ndc,
  name,
  date,
  qtyType,
  qty,
}) => (
  <Wrappers.DonationItem>
    <Donations.DonationItemField>
      {ndc}
    </Donations.DonationItemField>
    <Donations.DonationItemField>
      {name}
    </Donations.DonationItemField>
    <Donations.DonationItemField>
      {date}
    </Donations.DonationItemField>
    <Donations.DonationItemField>
      {qtyType}
    </Donations.DonationItemField>
    <Donations.DonationItemField>
      {qty}
    </Donations.DonationItemField>
  </Wrappers.DonationItem>
);

export default DonationItem;
