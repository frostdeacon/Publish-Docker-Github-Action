// LIBS
import React from 'react';

// COMPONENTS
import DonationItem from './DonationItem';
import DonationHeaderDonor from './DonationHeaderDonor';
import DonationHeaderPharmacist from './DonationHeaderPharmacist';

// STYLED
import { Wrappers } from '../../../../../styled';

// HOC
import RoleHOC from '../../../../../hoc/Role';

const Donation = ({ donation }) => (
  <Wrappers.Donation>
    <RoleHOC access="donor">
      <DonationHeaderDonor
        status={donation.status}
        pharmacyAddress={donation.pharmacyAddress}
        id={donation.id}
      />
    </RoleHOC>
    <RoleHOC access="pharmacist">
      <DonationHeaderPharmacist
        pharmacyAddress={donation.pharmacyAddress}
        id={donation.id}
        from={donation.donator}
      />
    </RoleHOC>
    <DonationItem
      ndc="NDC"
      name="Drug Name"
      date="Expiration Date"
      qtyType="Quantity Type"
      qty="Quantity"
    />
    {
      donation.donation.packages.map((_package, i) => (
        <DonationItem
          // no unique id per donation package
          // eslint-disable-next-line
          key={i}
          ndc={_package.ndc}
          name={_package.name}
          date={_package.expiration_date}
          qtyType={_package.quantity_type}
          qty={_package.quantity}
        />
      ))
    }
    <DonationItem />
  </Wrappers.Donation>
);

export default Donation;
