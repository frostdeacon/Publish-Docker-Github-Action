// LIBS
import React from 'react';

// STYLED
import { Donations } from '../../../../../../styled';

const statuses = {
  0: 'On Review',
  1: 'Approved',
  2: 'Rejected',
};

const DonationHeaderDonor = ({ status, pharmacyAddress, id }) => (
  <Donations.DonationHeader>
    <Donations.DonationH3>{`Donation ${id} at ${pharmacyAddress}`}</Donations.DonationH3>
    <Donations.DonationStatus
      status={statuses[status]}
    >
      {statuses[status]}
    </Donations.DonationStatus>
  </Donations.DonationHeader>
);

export default DonationHeaderDonor;
