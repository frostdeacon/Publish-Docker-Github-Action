// LIBS
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';

// STYLED
import { Donations } from '../../../../../../styled';

// REDUX
import { keystoreSelectors } from '../../../../../../redux/selectors';
import { contractActions } from '../../../../../../redux/actions';

// ROUTER
import { routes } from '../../../../../../router';

const DonationHeaderPharmacist = ({ pharmacyAddress, id, from }) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const account = useSelector(keystoreSelectors.selectAccount);

  const toSignInKeystore = () => history.push(routes.signInKeystore);

  const approveDonation = () => {
    dispatch(contractActions.pharmacy.approveDonation.call({ pharmacyAddress, id }));
  };

  const rejectDonation = () => {
    dispatch(contractActions.pharmacy.rejectDonation.call({ pharmacyAddress, id }));
  };

  return (
    <Donations.DonationHeader>
      <Donations.DonationH3>{`Donation ${id} from ${from}`}</Donations.DonationH3>
      {
        account
          ? (
            <>
              <Donations.DonationHeaderButtonApprove
                value="APPROVE"
                onClick={approveDonation}
              />
              <Donations.DonationHeaderButtonReject
                value="REJECT"
                onClick={rejectDonation}
              />
            </>
          )
          : (
            <Donations.DonationHeaderPaleButtonSignIn
              value="SIGN IN WITH KEYSTORE"
              onClick={toSignInKeystore}
            />
          )
      }
    </Donations.DonationHeader>
  );
};

export default DonationHeaderPharmacist;
