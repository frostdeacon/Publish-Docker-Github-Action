// LIBS
import React from 'react';
import { useHistory } from 'react-router-dom';

// STYLED
import { Donations } from '../../../../styled';

// ROUTER
import { routes } from '../../../../router';

const NoKeystore = () => {
  const history = useHistory();

  const toSignInKeystore = () => history.push(routes.signInKeystore);

  return (
    <>
      <Donations.NoKeystoreH3>
        Sign in with your keystore to create donation
      </Donations.NoKeystoreH3>
      <Donations.NoKeystorePaleButton
        value="SIGN IN WITH KEYSTORE"
        onClick={toSignInKeystore}
      />
    </>
  );
};

export default NoKeystore;
