// LIBS
import React from 'react';

// STYLED
import { Donations } from '../../../../../styled';
import { Inputs } from '../../../../../styled/backbone';

// COMPONENTS
import { CheckboxInput } from '../../../../InputComponents';

const AddDonationsAgreement = ({
  register,
  onSubmit,
}) => (
  <Donations.AgreementWrapper>
    <Donations.ContentWrapper>
      <Donations.CheckboxesWrapper>
        <CheckboxInput register={register} name="rules" required />
        <CheckboxInput register={register} name="agreement" required />
      </Donations.CheckboxesWrapper>
      <Donations.RulesWrapper>
        <Donations.AgreementH5Black>
          I agree not to donate:
        </Donations.AgreementH5Black>
        <Donations.AgreementH5Grey>
          1. Non-controlled substance (no narcotics or opiodis)
        </Donations.AgreementH5Grey>
        <Donations.AgreementH5Grey>
          2. Items will not expire for at least 3 months
        </Donations.AgreementH5Grey>
        <Donations.AgreementH5Grey>
          3. Is in sealed package
        </Donations.AgreementH5Grey>
        <Donations.AgreementH5Grey>
          4. Does not require refrigeration
        </Donations.AgreementH5Grey>
        <Donations.AgreementH5Grey>
          I have read and accept Save Donor Agreement
        </Donations.AgreementH5Grey>
      </Donations.RulesWrapper>
    </Donations.ContentWrapper>
    <Inputs.Button sm onClick={onSubmit} value="CONFIRM LIST" />
  </Donations.AgreementWrapper>
);

export default AddDonationsAgreement;
