// LIBS
import React from 'react';
import { useSelector } from 'react-redux';

// STYLED
import { Donations } from '../../../../../styled';
import RemoveIcon from '../../../../../assets/icons/remove-urn.svg';
import RemoveHoverIcon from '../../../../../assets/icons/remove-urn-hover.svg';
import { SelectInput } from '../../../../InputComponents';

// REDUX
import { pharmaciesSelectors } from '../../../../../redux/selectors';

const AddDonationsButtons = ({
  addItem,
  removeAllItems,
  register,
}) => {
  const pharmacies = useSelector(pharmaciesSelectors.selectPharmacies);

  const pharmaciesOptions = pharmacies.length > 0 ? pharmacies.map((pharmacy) => ({
    key: pharmacy,
    value: pharmacy,
  })) : null;

  return (
    <Donations.ButtonsWrapper>
      <Donations.AddItemButton onClick={addItem} value="ADD ANOTHER ITEM" />
      <Donations.RemoveAll onClick={removeAllItems}>
        <img
          src={RemoveIcon}
          alt=""
        />
        <img
          src={RemoveHoverIcon}
          alt=""
          className="hover"
        />
        <Donations.RemoveH4>Remove all drugs</Donations.RemoveH4>
      </Donations.RemoveAll>
      {
        pharmaciesOptions && (
          <Donations.PharmaciesSelect>
            <SelectInput
              register={register}
              name="pharmacy"
              defaultValue={pharmaciesOptions[0].value}
              options={pharmaciesOptions}
            />
          </Donations.PharmaciesSelect>
        )
      }
    </Donations.ButtonsWrapper>
  );
};

export default AddDonationsButtons;
