// LIBS
import React from 'react';

// STYLED
import { Donations } from '../../../../../styled';
import NDCExample from '../../../../../assets/icons/ndc-example.svg';

const AddDonationsNDC = () => (
  <Donations.NDCWrapper>
    <Donations.NDCH5>
      National Drug Code (NDC):
    </Donations.NDCH5>
    <img src={NDCExample} alt="" />
    <Donations.NDCBorder1 />
    <Donations.NDCBorder2 />
  </Donations.NDCWrapper>
);

export default AddDonationsNDC;
