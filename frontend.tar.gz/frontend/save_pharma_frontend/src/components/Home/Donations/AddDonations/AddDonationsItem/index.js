// LIBS
import React from 'react';

// COMPONENTS
import { TextInput, CounterInput } from '../../../../InputComponents';

// STYLED
import { Donations } from '../../../../../styled';
import RemoveIcon from '../../../../../assets/icons/remove-urn.svg';
import RemoveHoverIcon from '../../../../../assets/icons/remove-urn-hover.svg';

const Inputs = [
  {
    title: 'National Drug Code (NDC)',
    name: 'ndc',
    width: 225,
    placeholder: '10 or 11 digit number',
  },
  {
    title: 'Drug Name & Strenght',
    name: 'name',
    width: 235,
    placeholder: 'e.g. Amoxicillin 500 mg',
  },
  {
    title: 'Expiration Date',
    name: 'expiration_date',
    width: 160,
    placeholder: 'mm/dd/yyyy',
  },
  {
    title: 'Qty type',
    name: 'quantity_type',
    width: 160,
    placeholder: 'Choose type',
  },
];

const AddDonationsItem = ({
  register,
  id,
  removeItem,
  errors,
}) => {
  const handleRemove = () => removeItem(id);

  return (
    <Donations.Item>
      {
        Inputs.map((input) => (
          <Donations.ItemInputWrapper key={`${id}-${input.name}`}>
            <Donations.ItemInputTitle>
              {input.title}
            </Donations.ItemInputTitle>
            <TextInput
              register={register}
              name={`${id}-${input.name}`}
              width={input.width}
              placeholder={input.placeholder}
              required
              error={errors && errors[`${id}-${input.name}`]}
            />
          </Donations.ItemInputWrapper>
        ))
      }
      <Donations.ItemInputWrapper>
        <Donations.ItemInputTitle>
          Qty
        </Donations.ItemInputTitle>
        <CounterInput register={register} name={`${id}-quantity`} />
      </Donations.ItemInputWrapper>
      <Donations.ItemIcon onClick={handleRemove}>
        <img
          src={RemoveIcon}
          alt=""
        />
        <img
          src={RemoveHoverIcon}
          alt=""
          className="hover"
        />
      </Donations.ItemIcon>
    </Donations.Item>
  );
};

export default AddDonationsItem;
