// LIBS
import React, { useState } from 'react';
import useForm from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';

// STYLED
import { Donations } from '../../../../styled';

// COMPONENTS
import AddDonationsItem from './AddDonationsItem';
import AddDonationsButtons from './AddDonationsButtons';
import AddDonationsAgreement from './AddDonationsAgreement';
import AddDonationsNDC from './AddDonationsNDC';

// REDUX
import { contractActions } from '../../../../redux/actions';

const AddDonations = ({ showDonationsList }) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { register, handleSubmit, errors } = useForm();
  const [itemQty, setItemQty] = useState([0]);
  const [nextItemId, setNextItemId] = useState(1);

  const addItem = () => {
    setItemQty([...itemQty, nextItemId]);
    setNextItemId(nextItemId + 1);
  };

  const removeItem = (targetId) => {
    if (itemQty.length === 1) {
      showDonationsList();
    } else {
      setItemQty(itemQty.filter((id) => id !== targetId));
    }
  };

  const removeAllItems = () => {
    showDonationsList();
  };

  const onSubmit = (values) => {
    const {
      rules,
      agreement,
      pharmacy,
      ...inputs
    } = values;

    const rawDonation = Object.entries(inputs).reduce((accum, item) => {
      const result = accum;
      const [id, field] = item[0].split('-');
      const value = field === 'quantity' ? Number(item[1]) : item[1];

      if (result[id]) {
        result[id][field] = value;
      } else {
        result[id] = {
          [field]: value,
        };
      }

      return result;
    }, []);

    const donation = rawDonation.filter((item) => item);

    dispatch(contractActions.pharmacy.addDonation.call({
      donation,
      contractAddress: pharmacy,
      history,
    }));
  };

  return (
    <>
      {
        itemQty.map((id) => (
          <AddDonationsItem
            key={id}
            register={register}
            id={id}
            removeItem={removeItem}
            errors={errors}
          />
        ))
      }
      <AddDonationsButtons
        addItem={addItem}
        removeAllItems={removeAllItems}
        register={register}
      />
      <Donations.BottomWrapper>
        <AddDonationsAgreement
          register={register}
          onSubmit={handleSubmit(onSubmit)}
        />
        <AddDonationsNDC />
      </Donations.BottomWrapper>
    </>
  );
};

export default AddDonations;
