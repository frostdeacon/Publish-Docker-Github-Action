// LIBS
import React, { useState, useRef, useCallback } from 'react';
import { useLocation, useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';

// ROUTER
import { routes } from '../../../router';

// STYLED
import { Wrappers, Home } from '../../../styled';
import CarretDownIcon from '../../../assets/icons/carret-down.svg';
import LogoutIcon from '../../../assets/icons/navigation-logout.svg';
import LogoutHoverIcon from '../../../assets/icons/navigation-logout-hover.svg';

// REDUX
import { authActions } from '../../../redux/actions';

const titles = {
  [routes.homeDashboard]: 'Dashboard',
  [routes.homeDonations]: 'Donations',
  [routes.homeActiveInventory]: 'Active Inventory',
  [routes.homeTransactions]: 'Transactions',
  [routes.homeSaveCoinMarket]: 'Save Coin Market',
};

const HomeHeader = () => {
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const dropdown = useRef(null);
  const dropdownTrigger = useRef(null);
  const [isShowDropdown, setIsShowDropdown] = useState(false);

  const closeDropdown = useCallback((e) => {
    if (e) {
      if (dropdownTrigger.current.contains(e.target)) return;
      if (dropdown.current.contains(e.target)) return;
    }

    setIsShowDropdown(false);
    document.body.removeEventListener('click', closeDropdown);
  }, []);

  const handleShowDropdown = () => {
    if (!isShowDropdown) {
      setIsShowDropdown(true);
      document.body.addEventListener('click', closeDropdown);
    } else {
      setIsShowDropdown(false);
      document.body.removeEventListener('click', closeDropdown);
    }
  };

  const handleLogout = () => {
    closeDropdown();
    dispatch(authActions.signOut.call(history));
  };

  return (
    <Wrappers.HomeHeader>
      <Home.HeaderH3>{titles[location.pathname]}</Home.HeaderH3>
      <Home.HeaderAccount onClick={handleShowDropdown} ref={dropdownTrigger}>
        <Home.HeaderAccountH5>John Doe</Home.HeaderAccountH5>
        <img
          src={CarretDownIcon}
          alt=""
        />
      </Home.HeaderAccount>
      {
        isShowDropdown
          && (
            <Home.Dropdown ref={dropdown}>
              <Home.DropdownLogout onClick={handleLogout}>
                <img
                  src={LogoutIcon}
                  alt=""
                />
                <img
                  src={LogoutHoverIcon}
                  alt=""
                  className="hover"
                />
                <Home.DropdownH5>Logout</Home.DropdownH5>
              </Home.DropdownLogout>
            </Home.Dropdown>
          )
      }
    </Wrappers.HomeHeader>
  );
};

export default HomeHeader;
