// LIBS
import React from 'react';

// STYLED
import { Wrappers, Home } from '../../../styled';
import SaveLogo from '../../../assets/icons/save-logo.svg';
import DashboardIcon from '../../../assets/icons/navigation-dashboard.svg';
import DonationsIcon from '../../../assets/icons/navigation-donations.svg';
import InventoryIcon from '../../../assets/icons/navigation-inventory.svg';
import TransactionsIcon from '../../../assets/icons/navigation-transactions.svg';
import MarketIcon from '../../../assets/icons/navigation-market.svg';
import MarketActiveIcon from '../../../assets/icons/navigation-market-active.svg';
import TransactionsActiveIcon from '../../../assets/icons/navigation-transactions-active.svg';
import InventoryActiveIcon from '../../../assets/icons/navigation-inventory-active.svg';
import DonationsActiveIcon from '../../../assets/icons/navigation-donations-active.svg';
import DashboardActiveIcon from '../../../assets/icons/navigation-dashboard-active.svg';

// ROUTER
import { routes } from '../../../router';

// COMPONENTS
import NavigationLink from '../NavigationLink';

const NavigationList = [
  {
    route: routes.homeDashboard,
    title: 'DASHBOARD',
    icon: DashboardIcon,
    activeIcon: DashboardActiveIcon,
  },
  {
    route: routes.homeDonations,
    title: 'DONATIONS',
    icon: DonationsIcon,
    activeIcon: DonationsActiveIcon,
  },
  {
    route: routes.homeActiveInventory,
    title: 'ACTIVE INVENTORY',
    icon: InventoryIcon,
    activeIcon: InventoryActiveIcon,
  },
  {
    route: routes.homeTransactions,
    title: 'TRANSACTIONS',
    icon: TransactionsIcon,
    activeIcon: TransactionsActiveIcon,
  },
  {
    route: routes.homeSaveCoinMarket,
    title: 'SAVE COIN MARKET',
    icon: MarketIcon,
    activeIcon: MarketActiveIcon,
  },
];


const HomeNavigation = () => (
  <Wrappers.HomeNavigation>
    <Home.NavigationLogo
      src={SaveLogo}
    />
    {
      NavigationList.map(({
        route,
        icon,
        activeIcon,
        title,
      }) => (
        <NavigationLink
          key={route}
          route={route}
          title={title}
          icon={icon}
          activeIcon={activeIcon}
        />
      ))
    }
    <Home.NavigationH5>
      &copy; 2020 Save Pharmaceutical
    </Home.NavigationH5>
  </Wrappers.HomeNavigation>
);

export default HomeNavigation;
