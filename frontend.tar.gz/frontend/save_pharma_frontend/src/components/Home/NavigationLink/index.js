// LIBS
import React from 'react';

// STYLED
import { Home } from '../../../styled';

const NavigationLink = ({
  route,
  title,
  icon,
  activeIcon,
}) => (
  <Home.NavigationLink
    to={route}
    activeClassName="active"
  >
    <img src={icon} alt="" />
    <img src={activeIcon} alt="" className="active-icon" />
    <span>{title}</span>
    <div />
  </Home.NavigationLink>
);

export default NavigationLink;
