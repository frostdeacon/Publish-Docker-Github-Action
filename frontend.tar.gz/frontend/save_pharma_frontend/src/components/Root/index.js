import React from 'react';
import { useHistory } from 'react-router-dom';
import { routes } from '../../router';
import { Containers, Root as RootStyled, Wrappers } from '../../styled';

const Root = () => {
  const history = useHistory();

  const toSignIn = () => history.push(routes.signIn);

  const toSignUp = () => history.push(routes.signUp);

  return (
    <Containers.Root>
      <RootStyled.H1>Save Medication</RootStyled.H1>
      <RootStyled.H4>Easily donate drugs you no longer use to those in need</RootStyled.H4>
      <Wrappers.RootLinks>
        <RootStyled.LinkButton
          onClick={toSignIn}
          value="SIGN IN"
        />
        <RootStyled.LinkButton
          onClick={toSignUp}
          value="SIGN UP"
        />
      </Wrappers.RootLinks>
    </Containers.Root>
  );
};

export default Root;
