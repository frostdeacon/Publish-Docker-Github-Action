import React from 'react';
import { shallow } from 'enzyme';

import Home from '.';

describe('Home', () => {
  it('should renders correctly', () => {
    const component = shallow(<Home />);

    expect(component).toMatchSnapshot();
  });
});
