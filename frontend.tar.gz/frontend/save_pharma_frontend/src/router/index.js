import routes from './routes';

export {
  routes,
};
