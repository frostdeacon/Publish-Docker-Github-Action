import styled from 'styled-components';
import colors from '../colors';
import { Texts, Inputs } from './backbone';
import fonts from '../fonts';

const CreatePasswordH2 = styled(Texts.H2)`
  color: ${colors.mainBlack};
  padding: 0 45px;
  margin-bottom: 20px;
`;

const CreatePasswordH4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 25px;
`;

const CreatePasswordForm = styled.form`
  margin-bottom: 40px;
  text-align: center;
`;

const CreatePasswordSubmit = styled(Inputs.Submit)`
  margin-top: 20px;
`;

const CreatePasswordError = styled(Texts.Error)`
  color: ${colors.error};
  text-align: left;
  margin: 10px 0 -5px;
`;

const CreatePasswordFooter = styled(Texts.H5)`
  background: ${colors.lightgrey};
  width: 100%;
  text-align: center;
  padding: 20px 0;
  border-radius: 0px 0px 8px 8px;
`;

const CreatePasswordFooterLink = styled(Texts.RouterLink)``;

const CreatePasswordReminder = styled(Texts.H5)`
  color: ${colors.darkgrey};
  
  &>span {
    color: ${colors.purple};
  }
`;

const GenerateMnemonicH2 = styled(Texts.H2)`
  color: ${colors.mainBlack};
  margin-bottom: 15px;
`;

const GenerateMnemonicH5 = styled(Texts.H5)`
  color: ${colors.darkgrey};
  margin: 0 -5px 25px;
`;

const MnemonicActions = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 25px;
`;

const MnemonicAction = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
`;

const MnemonicActionImage = styled.img`
  width: 20px;
  height: 20px;
  margin-right: 10px;
`;

const MnemonicActionTitle = styled.span`
  font-size: 12px;
  line-height: 14px;
  font-family: ${fonts.medium};
  color: ${colors.purple};
`;

const MnemonicWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 10px;
`;

const GenerateMnemonicButton = styled(Inputs.Button)``;

const ConfirmMnemonicH2 = styled(Texts.H2)`
  color: ${colors.mainBlack};
  margin-bottom: 15px;
`;

const ConfirmMnemonicH5 = styled(Texts.H5)`
  color: ${colors.darkgrey};
  margin: 0 0 20px;
`;

const ConfirmMnemonicButton = styled(Inputs.Button)``;

const DownloadKeystoreH3 = styled(Texts.H3)`
  color: ${colors.mainBlack};
  margin-bottom: 5px;
`;

const DownloadKeystoreH4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 20px;
`;

const DownloadKeystoreButton = styled(Inputs.Button)``;

const DownloadKeystorePaleButton = styled(Inputs.PaleButton)`
  margin-top: 20px;
`;

const DownloadKeystoreImg = styled.img`
  margin-bottom: 30px;
`;

const DownloadKeystoreReminder = styled(Texts.H5)`
color: ${colors.darkgrey};

&>span {
  color: ${colors.purple};
}
`;

export {
  CreatePasswordH2,
  CreatePasswordH4,
  CreatePasswordForm,
  CreatePasswordSubmit,
  CreatePasswordFooter,
  CreatePasswordFooterLink,
  CreatePasswordReminder,
  CreatePasswordError,
  GenerateMnemonicH2,
  GenerateMnemonicH5,
  MnemonicActions,
  MnemonicAction,
  MnemonicActionImage,
  MnemonicActionTitle,
  MnemonicWrapper,
  GenerateMnemonicButton,
  ConfirmMnemonicH2,
  ConfirmMnemonicH5,
  ConfirmMnemonicButton,
  DownloadKeystoreH3,
  DownloadKeystoreH4,
  DownloadKeystoreButton,
  DownloadKeystoreImg,
  DownloadKeystorePaleButton,
  DownloadKeystoreReminder,
};
