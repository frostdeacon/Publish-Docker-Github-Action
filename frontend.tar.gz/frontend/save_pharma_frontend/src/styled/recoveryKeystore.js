import styled from 'styled-components';
import colors from '../colors';
import { Texts, Inputs } from './backbone';

const EnterMnemonicH2 = styled(Texts.H2)`
  color: ${colors.mainBlack};
  margin-bottom: 15px;
`;

const EnterMnemonicH5 = styled(Texts.H5)`
  color: ${colors.darkgrey};
  margin: 0 0 30px;
`;

const EnterMnemonicButton = styled(Inputs.Button)``;

const EnterMnemonicWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 10px;
`;

const EnterPasswordH3 = styled(Texts.H3)`
  color: ${colors.mainBlack};
  margin-bottom: 5px;
`;

const EnterPasswordH4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 20px;
`;

const EnterPasswordForm = styled.form`
  text-align: center;
`;

const EnterPasswordSubmit = styled(Inputs.Submit)`
  margin-top: 20px;
`;

const EnterPasswordIcon = styled.img`
  margin-bottom: 30px;
`;

const DownloadKeystoreH4 = styled(EnterPasswordH4)`
  padding: 0 100px;
`;

const DownloadKeystoreH3 = styled(EnterPasswordH3)``;
const DownloadKeystoreIcon = styled(EnterPasswordIcon)``;
const DownloadKeystoreButton = styled(Inputs.Button)``;

const DownloadKeystoreSignInButton = styled(Inputs.PaleButton)`
  margin-top: 20px;
`;

export {
  EnterMnemonicH2,
  EnterMnemonicH5,
  EnterMnemonicButton,
  EnterMnemonicWrapper,
  EnterPasswordH3,
  EnterPasswordH4,
  EnterPasswordForm,
  EnterPasswordSubmit,
  EnterPasswordIcon,
  DownloadKeystoreH3,
  DownloadKeystoreH4,
  DownloadKeystoreIcon,
  DownloadKeystoreButton,
  DownloadKeystoreSignInButton,
};
