import styled from 'styled-components';
import { Texts, Inputs } from './backbone';
import colors from '../colors';

const H2 = styled(Texts.H2)`
  margin-bottom: 20px;
  color: ${colors.mainBlack};
`;

const H4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 30px;
`;

const Submit = styled(Inputs.Button)``;

const InputsWrapper = styled.div`
  margin-bottom: 20px;
`;

const InputError = styled(Texts.Error)`
  color: ${colors.error};
  text-align: left;
  margin: 5px 0px -15px;
  max-width: 350px;
`;

const SuccessImg = styled.img`
  margin-bottom: 30px;
`;

const SuccessH3 = styled(Texts.H3)`
  color: ${colors.mainBlack};
  margin-bottom: 5px;
`;

const SuccessH4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 20px;
`;

const SuccessPaleButton = styled(Inputs.PaleButton)`
  margin-top: 20px;
`;

export {
  H2,
  H4,
  Submit,
  InputsWrapper,
  InputError,
  SuccessImg,
  SuccessH3,
  SuccessH4,
  SuccessPaleButton,
};
