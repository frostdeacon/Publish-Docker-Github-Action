import styled from 'styled-components';
import { Texts, Inputs } from './backbone';
import colors from '../colors';

const AddH1 = styled(Texts.H1)`
  color: ${colors.mainBlack};
  margin-bottom: 40px;
`;

const Item = styled.div`
  background: ${colors.white};
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  padding: 25px 20px 30px 30px;
  margin: 0 auto 30px;
  display: flex;
`;

const ItemInputTitle = styled(Texts.InputTitle)`
  color: ${colors.mainBlack};
  margin-bottom: 13px;
`;

const ItemInputWrapper = styled.div`
  margin-right: 20px;
`;

const ItemIcon = styled.div`
  display: flex;
  cursor: pointer;
  padding-top: 29px;

  & img.hover {
    display: none;
  }

  &:hover {
    img {
      display: none;
    }

    img.hover {
      display: initial;
    }
  }
`;

const AddItemButton = styled(Inputs.PaleButton)`
  border-radius: 2px;
  width: 255px;
  margin-right: 20px;
`;

const ButtonsWrapper = styled.div`
  display: flex;
  margin-bottom: 45px;
`;

const RemoveAll = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;

  & img.hover {
    display: none;
  }

  &:hover {
    img {
      display: none;
    }

    img.hover {
      display: initial;
    }

    div {
      color: ${colors.errorGrad};
    }
  }
`;

const RemoveH4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-left: 10px;
`;

const BottomWrapper = styled.div`
  display: flex;
  justify-content: space-between;
`;

const AgreementWrapper = styled.div`
  padding: 40px;
  background: ${colors.lightgrey};
  width: 445px;
  border-radius: 8px;
  box-sizing: border-box;
`;

const ContentWrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  margin-bottom: 35px;
`;

const CheckboxesWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin-right: 15px;
  padding-top: 3px;
`;

const RulesWrapper = styled.div`
  &>div {
    text-align: left;

    &:last-child {
      margin-top: 20px;
    }
  }
`;

const NDCWrapper = styled.div`
  width: 585px;
  background: ${colors.lightgrey};
  border-radius: 8px;
  box-sizing: border-box;
  padding: 30px 0px 30px 40px;
  position: relative;
`;

const NDCH5 = styled(Texts.H5)`
  color: ${colors.mainBlack};
  margin-bottom: 10px;
  text-align: left;
`;

const NDCBorder1 = styled.div`
  position: absolute;
  width: 87px;
  height: 19px;
  top: 96px;
  left: 200px;
  border: 2px solid ${colors.error};
  box-sizing: border-box;
`;

const NDCBorder2 = styled.div`
  position: absolute;
  width: 20px;
  height: 116px;
  left: 448px;
  top: 116px;
  border: 2px solid ${colors.error};
  box-sizing: border-box;
`;

const AgreementH5Black = styled(Texts.H5)`
  color: ${colors.mainBlack};
  margin-bottom: 5px;
`;

const AgreementH5Grey = styled(Texts.H5)`
  color: ${colors.darkgrey};
`;

const ListAddItemButton = styled(Inputs.PaleButton)`
  border-radius: 2px;
  width: 255px;
  align-self: center;
  margin-bottom: 40px;
`;

const NoAddressH3 = styled(Texts.H3)`
  color: ${colors.mainBlack};
  margin-bottom: 40px;
`;

const NoAddressPaleButton = styled(ListAddItemButton)``;

const NoKeystoreH3 = styled(NoAddressH3)``;

const NoKeystorePaleButton = styled(NoAddressPaleButton)``;

const DonationH3 = styled(Texts.H3)`
  color: ${colors.mainBlack};
`;

const DonationHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  align-items: center;
`;

const DonationStatus = styled(DonationH3)`
  color: ${(props) => {
    if (props.status === 'Approved') return colors.statusApproved;
    if (props.status === 'Rejected') return colors.statusRejected;

    return colors.statusReview;
  }};
`;

const DonationItemField = styled(Texts.H4)`
  width: 20%;
  color: ${colors.mainBlack};
  text-align: left;
`;

const DonationHeaderButtonApprove = styled(Inputs.Button).attrs(() => ({
  xs: true,
  background: colors.statusApproved,
}))`
  margin-left: auto;
`;

const DonationHeaderButtonReject = styled(Inputs.Button).attrs(() => ({
  xs: true,
  background: colors.statusRejected,
}))``;

const PharmaciesSelect = styled.div`
  margin-left: auto;
`;

const DonationHeaderPaleButtonSignIn = styled(Inputs.PaleButton).attrs(() => ({
  sm: true,
}))`
  margin-left: auto;
`;

export {
  AddH1,
  Item,
  ItemInputTitle,
  ItemInputWrapper,
  ItemIcon,
  AddItemButton,
  ButtonsWrapper,
  RemoveAll,
  RemoveH4,
  BottomWrapper,
  AgreementWrapper,
  NDCWrapper,
  AgreementH5Grey,
  AgreementH5Black,
  ContentWrapper,
  CheckboxesWrapper,
  RulesWrapper,
  NDCH5,
  NDCBorder1,
  NDCBorder2,
  ListAddItemButton,
  NoAddressH3,
  NoAddressPaleButton,
  NoKeystoreH3,
  NoKeystorePaleButton,
  DonationH3,
  DonationHeader,
  DonationStatus,
  DonationItemField,
  DonationHeaderButtonApprove,
  DonationHeaderButtonReject,
  PharmaciesSelect,
  DonationHeaderPaleButtonSignIn,
};
