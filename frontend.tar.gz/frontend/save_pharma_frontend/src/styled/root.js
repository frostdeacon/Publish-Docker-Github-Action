import styled from 'styled-components';
import { Texts, Inputs } from './backbone';
import colors from '../colors';

const H1 = styled(Texts.H1)`
  color: ${colors.mainBlack};
  margin-bottom: 40px;
`;

const H4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 75px;
`;

const LinkButton = styled(Inputs.Button).attrs(() => ({
  sm: true,
}))`
  margin: 0 10px;
`;

export {
  H1,
  H4,
  LinkButton,
};
