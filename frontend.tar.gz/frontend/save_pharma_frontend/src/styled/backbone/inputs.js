import styled from 'styled-components';
import fonts from '../../fonts';
import colors from '../../colors';

const Input = styled.input`
  background: ${colors.inputBackground};
  border-radius: 2px;
  width: ${(props) => props.width}px;
  padding: 12px 0 12px 15px;
  border: none;
  font-size: 16px;
  line-height: 24px;
  color: ${colors.mainBlack};
  font-family: ${fonts.regular};
  box-sizing: border-box;
  position: relative;

  ${(props) => (!props.error
    ? `&:focus+div {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 3px;
      background: ${colors.btm};
      border-radius: 0 0 2px 2px;
    }`
    : `&+div {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 3px;
      background: ${colors.error};
      border-radius: 0 0 2px 2px;
    }`
  )}

  &::placeholder {
    font-size: 16px;
    line-height: 24px;
    font-family: ${fonts.regular};
    color: ${colors.inputPlaceholder};
  }
`;

const Text = styled(Input).attrs(() => ({
  type: 'text',
}))``;

const Password = styled(Input).attrs((props) => ({
  type: !props.show ? 'password' : 'text',
}))`
  padding-right: 50px;
`;

const PasswordEye = styled.img`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  right: 15px;
  cursor: pointer;
`;

const ClickInput = styled.input`
  background: ${(props) => (props.background ? props.background : colors.btm)};
  box-shadow: 0px 8px 60px rgba(131, 87, 177, 0.3);
  border-radius: 50px;
  width: ${(props) => {
    if (props.lg) return '410';
    if (props.sm) return '245';
    if (props.xs) return '155';

    return '350';
  }}px;
  font-size: 12px;
  line-height: 14px;
  font-family: ${fonts.medium};
  color: ${colors.white};
  padding: 17px 0;
  cursor: pointer;
`;

const PaleClickInput = styled(ClickInput).attrs(() => ({
  background: colors.paleBtm,
}))`
  box-shadow: none;
  color: ${colors.purple};
  border: none;
`;

const PaleButton = styled(PaleClickInput).attrs(() => ({
  type: 'button',
}))``;

const Button = styled(ClickInput).attrs(() => ({
  type: 'button',
}))``;

const Submit = styled(ClickInput).attrs(() => ({
  type: 'submit',
}))``;

const File = styled.input.attrs(() => ({
  type: 'file',
}))`
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
`;

const Mnemonic = styled.input.attrs(() => ({
  type: 'text',
}))`
  border: none;
  border-bottom: 1px solid ${(props) => {
    if (props.readOnly) return colors.mnemonicBorder;
    if (props.error) return colors.error;

    return colors.mainBlack;
  }};
  font-size: 14px;
  font-family: ${fonts.regular};
  line-height: 24px;
  color: ${colors.mainBlack};
  box-sizing: border-box;
  padding-left: ${(props) => (props.widePadding ? '23' : '15')}px;
  width: 100%;

  ${(props) => (!props.readOnly && !props.error
    && `&:focus {
      border-bottom: 1px solid ${colors.purple};
    }`
  )}


  &+span {
    font-size: 14px;
    font-family: ${fonts.regular};
    line-height: 34px;
    color: ${colors.inputPlaceholder};
    position: absolute;
    left: 0;
    top: -4px;
  }
`;

const Counter = styled.div`
  width: 110px;
  display: flex;
  background: ${colors.inputBackground};
  border-radius: 2px;
  padding: 12px 0;
`;

const CounterValue = styled.div`
  text-align: center;
  font-size: 16px;
  line-height: 24px;
  font-family: ${fonts.regular};
  color: ${colors.mainBlack};
  background: ${colors.inputBackground};
  width: 100%;
`;

const CounterAction = styled.div`
  text-align: center;
  font-size: 24px;
  line-height: 24px;
  font-family: ${fonts.regular};
  color: ${colors.inputPlaceholder};
  display: flex;
  justify-content: center;
  align-items: center;
  max-width: 40px;
  min-width: 40px;
  cursor: pointer;
`;

const HiddenInput = styled.input`
  border: 0;
  clip: rect(0 0 0 0);
  clip-path: inset(50%);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  white-space: nowrap;
  width: 1px;
`;

const CounterHiddenInput = styled(HiddenInput).attrs(() => ({
  type: 'number',
  readOnly: true,
}))``;

const HiddenCheckbox = styled(HiddenInput).attrs(() => ({
  type: 'checkbox',
  readOnly: true,
}))``;

const CheckboxIcon = styled.svg`
  fill: none;
  stroke: white;
  stroke-width: 2px;
`;

const StyledCheckbox = styled.div`
  display: inline-block;
  width: 18px;
  height: 18px;
  background: ${colors.purple};
  border-radius: 2px;
  transition: all 150ms;

  ${CheckboxIcon} {
    visibility: ${(props) => (props.checked ? 'visible' : 'hidden')}
  }
`;

const Select = styled.select`
  border-radius: 2px;
  width: ${(props) => props.width}px;
  border: none;
  font-size: 16px;
  line-height: 24px;
  color: ${colors.mainBlack};
  font-family: ${fonts.regular};
  height: 48px;
`;

const Option = styled.option``;


export {
  Text,
  File,
  Button,
  Submit,
  Password,
  PasswordEye,
  Mnemonic,
  PaleButton,
  Counter,
  CounterValue,
  CounterAction,
  CounterHiddenInput,
  HiddenCheckbox,
  StyledCheckbox,
  CheckboxIcon,
  Select,
  Option,
};
