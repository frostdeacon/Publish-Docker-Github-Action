import styled from 'styled-components';
import { Link } from 'react-router-dom';
import fonts from '../../fonts';

const H1 = styled.div`
  text-align: center;
  font-size: 40px;
  line-height: 46px;
  font-family: ${fonts.bold};
`;

const H2 = styled.div`
  text-align: center;
  font-size: 30px;
  line-height: 40px;
  font-family: ${fonts.bold};
`;

const H3 = styled.div`
  text-align: center;
  font-size: 24px;
  line-height: 40px;
  font-family: ${fonts.bold};
`;

const H4 = styled.div`
  text-align: center;
  font-size: 16px;
  line-height: 24px;
  font-family: ${fonts.regular};
`;

const H5 = styled.div`
  text-align: center;
  font-size: 14px;
  line-height: 24px;
  font-family: ${fonts.regular};
`;

const RouterLink = styled(Link)`
  font-family: ${fonts.regular};
  font-size: 14px;
  line-height: 24px;
`;

const Error = styled.div`
  font-size: 12px;
  line-height: 16px;
  font-family: ${fonts.regular};
`;

const InputTitle = styled.div`
  font-size: 14px;
  line-height: 16px;
  font-family: ${fonts.regular};
`;

export {
  H1,
  H2,
  H3,
  H4,
  H5,
  RouterLink,
  Error,
  InputTitle,
};
