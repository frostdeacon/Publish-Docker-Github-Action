import * as Inputs from './inputs';
import * as Texts from './texts';

export {
  Inputs,
  Texts,
};
