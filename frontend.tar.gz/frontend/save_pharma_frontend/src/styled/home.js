import styled from 'styled-components';
import { NavLink } from 'react-router-dom';
import colors from '../colors';
import fonts from '../fonts';
import { Texts } from './backbone';

const NavigationLogo = styled.img`
  margin-bottom: 40px;
`;

const NavigationLink = styled(NavLink)`
  color: ${colors.darkgrey};
  font-family: ${fonts.medium};
  font-size: 14px;
  line-height: 14px;
  padding: 20px 0 20px 25px;
  align-items: center;
  display: flex;
  text-decoration: none;
  width: calc(100% - 25px);
  position: relative;

  &>img {
    margin-top: -5px;
    margin-right: 10px;
  }

  &>img.active-icon {
    display: none;
  }

  &.active {
    box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
    color: ${colors.mainBlack};

    &>img {
      display: none;
    }

    &>img.active-icon {
      display: initial;
    }

    &>div {
      position: absolute;
      height: 100%;
      width: 4px;
      left: 0;
      top: 0
      background: ${colors.btm};
    }
  }
`;

const NavigationList = styled.div``;

const NavigationH5 = styled(Texts.H5)`
  color: ${colors.inputPlaceholder};
  margin-top: auto;
`;

const HeaderH3 = styled(Texts.H3)`
  color: ${colors.mainBlack};
`;

const HeaderAccount = styled.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`;

const HeaderAccountH5 = styled(Texts.H5)`
  color: ${colors.mainBlack};
  font-family: ${fonts.bold};
`;

const Dropdown = styled.div`
  position: absolute;
  right: 30px;
  top: 80px;
  width: 218px;
  background: ${colors.white};
  box-shadow: 5px 10px 25px rgba(0, 0, 0, 0.1);
  border-radius: 0px 0px 4px 4px;
  cursor: pointer;

  & img {
    margin-right: 10px;
  }

  & img.hover {
    display: none;
  }

  &:hover {
    img {
      display: none;
    }

    img.hover {
      display: initial;
    }

    div {
      color: ${colors.mainBlack};
    }
  }
`;

const DropdownLogout = styled.div`
  display: flex;
  padding: 10px 0 10px 20px;
  background: ${colors.lightgrey};
`;

const DropdownH5 = styled(Texts.H5)`
  color: ${colors.darkgrey};
`;

export {
  NavigationLogo,
  NavigationLink,
  NavigationList,
  NavigationH5,
  HeaderH3,
  HeaderAccount,
  HeaderAccountH5,
  Dropdown,
  DropdownH5,
  DropdownLogout,
};
