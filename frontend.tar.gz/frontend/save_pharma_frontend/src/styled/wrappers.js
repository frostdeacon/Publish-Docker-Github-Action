import styled from 'styled-components';
import colors from '../colors';

const CenterColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const SignInKeystore = styled.div`
  width: 410px;
  background: #FFFFFF;
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  padding-top: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const PasswordInput = styled.div`
  position: relative;
`;

const TextInput = styled.div`
  position: relative;
`;

const SignUpKeystoreCreatePassword = styled.div`
  width: 410px;
  background: #FFFFFF;
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  margin-top: 60px;
  margin-bottom: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 40px;
`;

const SignUpKeystoreCreatePasswordOuter = styled.div`
  display: flex;
  flex-direction: column;
`;

const SignUpKeystoreGenerateMnemonic = styled.div`
  width: 410px;
  background: #FFFFFF;
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 35px 65px 65px;
`;

const MnemonicInput = styled.div`
  position: relative;
  width: 30%;
  margin-bottom: 30px;
`;

const SignUpKeystoreConfirmMnemonic = styled.div`
  width: 410px;
  background: #FFFFFF;
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 50px 65px 65px;
`;

const RecoveryKeystoreEnterMnemonic = styled(SignUpKeystoreConfirmMnemonic)``;

const SignUpKeystoreDownloadKeystore = styled.div`
  width: 410px;
  background: #FFFFFF;
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 50px 0 30px;
  margin-bottom: 40px;
`;

const SignUpKeystoreDownloadKeystoreOuter = styled.div`
  display: flex;
  flex-direction: column;
`;

const RecoveryKeystoreEnterPassword = styled.div`
  width: 410px;
  background: #FFFFFF;
  box-shadow: 4px 3px 30px rgba(0, 0, 0, 0.09);
  border-radius: 8px;
  margin-top: 60px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 50px 0 30px;
`;

const RecoveryKeystoreDownloadKeystore = styled(RecoveryKeystoreEnterPassword)``;

const HomeNavigation = styled.div`
  padding: 30px 0 20px;
  width: 230px;
  align-items: center;
  display: flex;
  flex-direction: column;
  border-right: 1px solid ${colors.lightgreyBorder};
`;

const HomeHeader = styled.div`
  display: flex;
  padding: 20px 30px;
  border-bottom: 1px solid ${colors.lightgreyBorder};
  justify-content: space-between;
  align-items: center;
  position: relative;
`;

const HomeSection = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
`;

const HomeContent = styled.div`
  background: ${colors.inputBackground};
  flex-grow: 1;
`;

const Donations = styled.div`
  display: flex;
  flex-direction: column;
  padding: 70px 75px 50px;
`;

const SignIn = styled(SignInKeystore)`
  padding-bottom: 30px
`;

const SignUp = styled(SignIn)``;

const Donation = styled.div`
  border: 1px solid ${colors.lightgreyBorder};
  background: ${colors.white};
  border-radius: 4px;
  padding: 10px 40px;
  margin-bottom: 20px;
`;

const DonationItem = styled.div`
  display: flex;
  margin-bottom: 5px;
`;

const RootLinks = styled.div`
  display: flex;
  justify-content: center;
`;

export {
  CenterColumn,
  SignInKeystore,
  PasswordInput,
  SignUpKeystoreCreatePassword,
  SignUpKeystoreCreatePasswordOuter,
  SignUpKeystoreGenerateMnemonic,
  MnemonicInput,
  SignUpKeystoreConfirmMnemonic,
  SignUpKeystoreDownloadKeystore,
  SignUpKeystoreDownloadKeystoreOuter,
  RecoveryKeystoreEnterMnemonic,
  RecoveryKeystoreEnterPassword,
  RecoveryKeystoreDownloadKeystore,
  HomeNavigation,
  HomeHeader,
  HomeSection,
  HomeContent,
  Donations,
  TextInput,
  SignIn,
  SignUp,
  Donation,
  DonationItem,
  RootLinks,
};
