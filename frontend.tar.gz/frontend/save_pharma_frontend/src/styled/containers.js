import styled from 'styled-components';

const Container = styled.div`
  display: flex;
  justify-content: center;
`;

const Container150 = styled(Container)`
  padding-top: 150px;
`;

const Container90 = styled(Container)`
  padding-top: 90px;
`;

const SignInKeystore = styled(Container150)``;

const SignUpKeystore = styled(Container90)``;

const RecoveryKeystore = styled(Container90)``;

const Home = styled.div`
  display: flex;
  min-height: 100vh;
`;

const SignIn = styled(Container150)``;

const SignUp = styled(Container150)``;

const Root = styled(Container150)`
  flex-direction: column;
`;

export {
  SignInKeystore,
  SignUpKeystore,
  RecoveryKeystore,
  Home,
  SignIn,
  SignUp,
  Root,
};
