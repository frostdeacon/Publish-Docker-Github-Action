import styled from 'styled-components';
import { Texts, Inputs } from './backbone';
import colors from '../colors';

const H2 = styled(Texts.H2)`
  margin-bottom: 20px;
  color: ${colors.mainBlack};
`;

const H4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 30px;
`;

const Submit = styled(Inputs.Button)``;

const InputsWrapper = styled.div`
  margin-bottom: 20px;
`;

const InputError = styled(Texts.Error)`
  color: ${colors.error};
  text-align: left;
  margin: 5px 0px -15px;
`;

export {
  H2,
  H4,
  Submit,
  InputsWrapper,
  InputError,
};
