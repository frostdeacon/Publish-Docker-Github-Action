import styled from 'styled-components';
import colors from '../colors';
import { Texts, Inputs } from './backbone';

const IndexH2 = styled(Texts.H2)`
  margin-bottom: 20px;
  color: ${colors.mainBlack};
`;

const UploadKeystoreH4 = styled(Texts.H4)`
  padding: 0 90px;
  margin-bottom: 30px;
  color: ${colors.darkgrey};
`;

const UploadKeystoreLostLink = styled(Texts.RouterLink)`
  margin: 20px 0 35px;
  color: ${colors.btm};
`;

const UploadKeystoreFooter = styled(Texts.H5)`
  background: ${colors.lightgrey};
  width: 100%;
  text-align: center;
  padding: 20px 0;
  border-radius: 0px 0px 8px 8px;
`;

const UploadKeystoreSignupLink = styled(Texts.RouterLink)``;

const EnterPasswordH4 = styled(Texts.H4)`
  color: ${colors.darkgrey};
  margin-bottom: 30px;
`;

const EnterPasswordForm = styled.form`
  margin-bottom: 30px;
  text-align: center;
  display: flex;
  flex-direction: column;
`;

const EnterPasswordSubmit = styled(Inputs.Submit)`
  margin-top: 20px;
`;

const BackToUploadPaleButton = styled(Inputs.PaleButton)`
  margin-top: 10px;
`;

const EnterPasswordError = styled(Texts.Error)`
  color: ${colors.error};
  text-align: left;
  margin: 10px 0 -5px;
`;

export {
  IndexH2,
  UploadKeystoreH4,
  UploadKeystoreLostLink,
  UploadKeystoreFooter,
  UploadKeystoreSignupLink,
  EnterPasswordH4,
  EnterPasswordForm,
  EnterPasswordSubmit,
  EnterPasswordError,
  BackToUploadPaleButton,
};
