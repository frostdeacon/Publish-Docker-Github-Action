import web3 from '..';
import * as SaveMain from './SaveMain';
import * as Pharmacy from './Pharmacy';

const saveMain = new web3.eth.Contract(SaveMain.abi, SaveMain.address);
const pharmacyCreator = (contractAddress, accountAddress) => (
  new web3.eth.Contract(Pharmacy.abi, contractAddress, { from: accountAddress, gas: '3000000' })
);

export {
  saveMain,
  pharmacyCreator,
};
